package app.recitation.studio

import android.content.ContentValues
import android.content.Context
import android.graphics.Matrix
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbMatrix
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.roundToInt

fun fadeGain(tUs: Long, totalUs: Long, inUs: Long, outUs: Long): Float {
    var g = 1f
    if (inUs > 0 && tUs < inUs) g = minOf(g, tUs.toFloat() / inUs)
    if (outUs > 0 && tUs > totalUs - outUs) g = minOf(g, (totalUs - tUs).toFloat() / outUs)
    return g.coerceIn(0f, 1f)
}

/** تلاشي الصوت (ظهور/اختفاء تدريجي) */
@OptIn(UnstableApi::class)
class FadeAudioProcessor(
    private val totalUs: Long, private val inUs: Long, private val outUs: Long
) : BaseAudioProcessor() {
    private var frames = 0L

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT)
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        frames = 0L
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val size = inputBuffer.remaining()
        if (size == 0) return
        val out = replaceOutputBuffer(size)
        val ch = inputAudioFormat.channelCount
        val rate = inputAudioFormat.sampleRate
        while (inputBuffer.remaining() >= 2 * ch) {
            val g = fadeGain(frames * 1_000_000L / rate, totalUs, inUs, outUs)
            for (c in 0 until ch) {
                val s = inputBuffer.getShort().toInt()
                out.putShort((s * g).toInt().coerceIn(-32768, 32767).toShort())
            }
            frames++
        }
        out.flip()
    }
}

class Plan(
    val outW: Int, val outH: Int,
    val winWf: Float, val winHf: Float,
    val cropped: Boolean,
    val upscaled: Boolean,
    val fallback: Boolean,
    val centerAt: (Long) -> Pair<Float, Float>
)

class ExportOut(val file: File, val plan: Plan)

@OptIn(UnstableApi::class)
object Exporter {

    private fun even(v: Int) = (v and 1.inv()).coerceAtLeast(2)

    fun makePlan(s: Settings, srcW: Int, srcH: Int, track: TrackResult?): Plan {
        val a = when (s.orientation) {
            0 -> 9f / 16f
            1 -> 16f / 9f
            else -> srcW.toFloat() / srcH
        }
        val maxW: Float
        val maxH: Float
        if (srcW.toFloat() / srcH >= a) { maxH = srcH.toFloat(); maxW = maxH * a }
        else { maxW = srcW.toFloat(); maxH = maxW / a }

        val useFace = s.orientation != 2 && s.framing == 0 && track != null && track.detected > 0
        val fallback = s.orientation != 2 && s.framing == 0 && !useFace
        val anchorY = if (s.orientation == 0) 0.38f else 0.42f

        var winW = maxW
        if (s.orientation != 2) {
            if (useFace) {
                val ratios = if (s.orientation == 0) floatArrayOf(0.38f, 0.50f, 0.62f) else floatArrayOf(0.14f, 0.18f, 0.24f)
                winW = (track!!.faceW * srcW / ratios[s.faceSize.coerceIn(0, 2)]).coerceIn(maxW * 0.3f, maxW)
            } else if (s.framing == 2) {
                winW = maxW / s.manualZoom.coerceAtLeast(1f)
            }
        }
        val winH = winW / a
        val wf = winW / srcW
        val hf = winH / srcH

        val short = intArrayOf(0, 2160, 1440, 1080, 720, 480)[s.quality.coerceIn(0, 5)]
        val outW: Int
        val outH: Int
        if (short == 0) {
            outW = even(winW.roundToInt()); outH = even(winH.roundToInt())
        } else when (s.orientation) {
            0 -> { outW = even(short); outH = even(short * 16 / 9) }
            1 -> { outW = even(short * 16 / 9); outH = even(short) }
            else -> if (srcW < srcH) { outW = even(short); outH = even(short * srcH / srcW) }
            else { outW = even(short * srcW / srcH); outH = even(short) }
        }
        val upscaled = outW > winW * 1.02f || outH > winH * 1.02f

        val centerAt: (Long) -> Pair<Float, Float> = { t ->
            val (px, py) = when {
                s.orientation == 2 || s.framing == 1 || fallback -> 0.5f to 0.5f
                s.framing == 2 -> (s.manualX / 100f) to (s.manualY / 100f)
                else -> {
                    val (fx, fy) = track!!.valueAt(t)
                    fx to (fy + (0.5f - anchorY) * hf)
                }
            }
            px.coerceIn(wf / 2, 1f - wf / 2) to py.coerceIn(hf / 2, 1f - hf / 2)
        }
        return Plan(outW, outH, wf, hf, wf < 0.999f || hf < 0.999f, upscaled, fallback, centerAt)
    }

    suspend fun export(
        ctx: Context, uri: Uri, s: Settings, startMs: Long, endMs: Long,
        track: TrackResult?, onProgress: (Float) -> Unit
    ): ExportOut {
        val (srcW, srcH) = Tracker.videoSize(ctx, uri)
        val plan = makePlan(s, srcW, srcH, track)
        val totalUs = (endMs - startMs) * 1000

        val fadeUs: Long = if (s.fadeMode == 0) 0L
        else minOf((s.fadeSec * 1_000_000f).toLong(), totalUs / 2 - 20_000L).coerceAtLeast(50_000L)
        val fi = if (s.fadeMode == 1 || s.fadeMode == 2) fadeUs else 0L
        val fo = if (s.fadeMode == 1 || s.fadeMode == 3) fadeUs else 0L

        val video = mutableListOf<Effect>()
        if (plan.cropped || s.flipH || s.flipV) {
            video += object : MatrixTransformation {
                override fun getMatrix(presentationTimeUs: Long): Matrix {
                    val (px, py) = plan.centerAt(presentationTimeUs)
                    val m = Matrix()
                    m.postTranslate(-(2f * px - 1f), -(1f - 2f * py))
                    m.postScale(1f / plan.winWf, 1f / plan.winHf)
                    if (s.flipH || s.flipV) m.postScale(if (s.flipH) -1f else 1f, if (s.flipV) -1f else 1f)
                    return m
                }
            }
        }
        video += Presentation.createForWidthAndHeight(plan.outW, plan.outH, Presentation.LAYOUT_STRETCH_TO_FIT)
        if (fi > 0 || fo > 0) {
            video += object : RgbMatrix {
                override fun getMatrix(presentationTimeUs: Long, useHdr: Boolean): FloatArray {
                    val g = fadeGain(presentationTimeUs, totalUs, fi, fo)
                    return floatArrayOf(
                        g, 0f, 0f, 0f,
                        0f, g, 0f, 0f,
                        0f, 0f, g, 0f,
                        0f, 0f, 0f, 1f
                    )
                }
            }
        }
        val audio = mutableListOf<AudioProcessor>()
        if ((fi > 0 || fo > 0) && s.fadeAudio) audio += FadeAudioProcessor(totalUs, fi, fo)

        val item = MediaItem.Builder().setUri(uri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(startMs).setEndPositionMs(endMs).build()
            ).build()
        val edited = EditedMediaItem.Builder(item).setEffects(Effects(audio, video)).build()

        val out = File(ctx.cacheDir, "exp_${System.nanoTime()}.mp4")
        val bitrate = (plan.outW.toLong() * plan.outH * 30 * 0.17).toLong().coerceIn(2_000_000L, 45_000_000L).toInt()
        runTransformer(ctx, edited, out.absolutePath, bitrate, onProgress)
        return ExportOut(out, plan)
    }

    private suspend fun runTransformer(
        ctx: Context, edited: EditedMediaItem, path: String, bitrate: Int, onProgress: (Float) -> Unit
    ) = withContext(Dispatchers.Main) {
        suspendCancellableCoroutine<Unit> { cont ->
            val handler = Handler(Looper.getMainLooper())
            val holder = ProgressHolder()
            lateinit var transformer: Transformer
            val poll = object : Runnable {
                override fun run() {
                    if (transformer.getProgress(holder) != Transformer.PROGRESS_STATE_NOT_STARTED)
                        onProgress(holder.progress / 100f)
                    handler.postDelayed(this, 300)
                }
            }
            val encoder = DefaultEncoderFactory.Builder(ctx)
                .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(bitrate).build())
                .build()
            transformer = Transformer.Builder(ctx)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .setEncoderFactory(encoder)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        handler.removeCallbacks(poll)
                        if (cont.isActive) cont.resume(Unit)
                    }

                    override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                        handler.removeCallbacks(poll)
                        if (cont.isActive) cont.resumeWithException(exportException)
                    }
                })
                .build()
            cont.invokeOnCancellation {
                handler.post { handler.removeCallbacks(poll); transformer.cancel() }
            }
            transformer.start(edited, path)
            handler.post(poll)
        }
    }

    /** ينسخ الملف النهائي إلى Movies/Smart Recitation Studio ويعيد Uri */
    fun publish(ctx: Context, file: File, displayName: String, folder: String): Uri {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Smart Recitation Studio/$folder")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val resolver = ctx.contentResolver
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw UserError(tr("Could not create the output file.", "تعذّر إنشاء ملف الإخراج."))
        val os = resolver.openOutputStream(uri)
            ?: throw UserError(tr("Could not write the output file.", "تعذّرت كتابة ملف الإخراج."))
        os.use { o -> file.inputStream().use { it.copyTo(o) } }
        values.clear()
        values.put(MediaStore.Video.Media.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        file.delete()
        return uri
    }
}
