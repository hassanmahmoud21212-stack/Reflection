package app.recitation.studio

import android.content.Context
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CancellationException
import org.json.JSONObject
import java.io.File
import java.util.Locale

class DlResult(val file: File, val exact: Boolean)

class YtInfo(val title: String, val durationMs: Long, val thumb: String, val json: JSONObject)

/** تنزيل الجزء المطلوب فقط من YouTube. لا كوكيز ولا تجاوز لأي حماية. */
object YtDl {
    val YT_RE = Regex(
        "^(https?://)?(www\\.|m\\.|music\\.)?(youtube\\.com/(watch\\?|shorts/|live/|embed/)|youtu\\.be/)\\S+",
        RegexOption.IGNORE_CASE
    )

    /** يستخرج روابط YouTube من نص (يدعم نص «مشاركة» من تطبيق YouTube وعدة روابط) */
    fun extractLinks(text: String): List<String> =
        text.split(Regex("\\s+"))
            .map { it.trim().trimEnd(',', ';', ')', '.', '،') }
            .filter { YT_RE.matches(it) }
            .map { if (it.startsWith("http", ignoreCase = true)) it else "https://$it" }
            .distinct()

    private var inited = false
    @Volatile private var cancelled = false
    private val cache = HashMap<String, YtInfo>()

    @Synchronized
    private fun ensureInit(ctx: Context) {
        if (inited) return
        YoutubeDL.getInstance().init(ctx.applicationContext)
        FFmpeg.getInstance().init(ctx.applicationContext)
        inited = true
    }

    private fun initOrThrow(ctx: Context) {
        try { ensureInit(ctx) } catch (e: Throwable) {
            throw UserError(tr("Downloader failed to start: ", "تعذّر تشغيل أداة التنزيل: ") + (e.message ?: e.javaClass.simpleName))
        }
    }

    fun cancel(processId: String) {
        cancelled = true
        try { YoutubeDL.getInstance().destroyProcessById(processId) } catch (_: Throwable) {}
    }

    private fun sec(ms: Long) = String.format(Locale.US, "%.2f", ms / 1000.0)

    private fun accessProblem(m: String): String? {
        val low = m.lowercase()
        return when {
            "sign in to confirm" in low || "not a bot" in low || "cookies" in low ->
                tr("YouTube asks for sign-in/verification for this connection. This app doesn't use cookies or bypass it. Try another network or video.",
                    "يطلب YouTube تسجيل دخول/تحقق لهذا الاتصال. التطبيق لا يستخدم كوكيز ولا يتجاوز ذلك. جرّب شبكة أو فيديو آخر.")
            "private" in low || "members-only" in low || "members only" in low ->
                tr("The video is private or members-only.", "الفيديو خاص أو للأعضاء فقط.")
            "age" in low && ("restricted" in low || "verify" in low || "confirm" in low) ->
                tr("The video is age-restricted and needs sign-in.", "الفيديو مقيّد بالعمر ويحتاج تسجيل دخول.")
            "unavailable" in low || "not available" in low || "removed" in low || "does not exist" in low ->
                tr("The video is unavailable, removed, or blocked in your region.", "الفيديو غير متاح أو محذوف أو محجوب في منطقتك.")
            else -> null
        }
    }

    /** يحاول مرة، وإن فشل يحدّث yt-dlp ويعيد المحاولة مرة واحدة */
    private fun <T> withUpdateRetry(ctx: Context, block: () -> T): T {
        try {
            return block()
        } catch (e: UserError) {
            throw e
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            accessProblem(e.message ?: "")?.let { throw UserError(it) }
            try { YoutubeDL.getInstance().updateYoutubeDL(ctx.applicationContext) } catch (_: Throwable) {}
            try {
                return block()
            } catch (e2: Throwable) {
                if (e2 is UserError || e2 is CancellationException) throw e2
                val m = e2.message ?: e2.javaClass.simpleName
                throw UserError(accessProblem(m) ?: (tr("Failed: ", "فشل: ") + m.take(300)))
            }
        }
    }

    /** عنوان + مدة + صورة مصغّرة + قائمة الصيغ (طلب صغير، لا ينزّل الفيديو) */
    fun info(ctx: Context, url: String): YtInfo {
        synchronized(cache) { cache[url] }?.let { return it }
        initOrThrow(ctx)
        val j = withUpdateRetry(ctx) {
            val req = YoutubeDLRequest(url)
            req.addOption("--dump-json")
            req.addOption("--no-playlist")
            req.addOption("--no-warnings")
            val out = YoutubeDL.getInstance().execute(req).out
            val line = out.lineSequence().firstOrNull { it.trimStart().startsWith("{") }
                ?: throw UserError(tr("Could not read video info.", "تعذّرت قراءة معلومات الفيديو."))
            JSONObject(line)
        }
        val inf = YtInfo(
            j.optString("title", url), (j.optDouble("duration", 0.0) * 1000).toLong(),
            j.optString("thumbnail", ""), j
        )
        synchronized(cache) { cache[url] = inf }
        return inf
    }

    /** رابط بثّ منخفض الجودة (≤480p، فيديو+صوت معًا) للمعاينة فقط */
    fun previewStream(ctx: Context, url: String): Pair<String, Map<String, String>> {
        val fs = info(ctx, url).json.optJSONArray("formats")
            ?: throw UserError(tr("No preview stream available.", "لا يوجد بثّ معاينة متاح."))
        var best: JSONObject? = null
        for (i in 0 until fs.length()) {
            val f = fs.getJSONObject(i)
            val h = f.optInt("height", 0)
            val proto = f.optString("protocol", "")
            if (f.optString("vcodec", "none") != "none" && f.optString("acodec", "none") != "none" &&
                h in 1..480 && proto.startsWith("http") && !proto.contains("m3u8") && f.optString("url").isNotEmpty()
            ) {
                if (best == null || h > best.optInt("height", 0)) best = f
            }
        }
        val b = best ?: throw UserError(tr("No preview stream available.", "لا يوجد بثّ معاينة متاح."))
        val hd = mutableMapOf<String, String>()
        b.optJSONObject("http_headers")?.let { o -> o.keys().forEach { k -> hd[k] = o.optString(k) } }
        return b.getString("url") to hd
    }

    /** أقصى ارتفاع للتنزيل حسب الجودة المختارة ووضع التوفير */
    fun downloadHeight(s: Settings): Int {
        val base = intArrayOf(2160, 2160, 1440, 1080, 720, 480)[s.quality.coerceIn(0, 5)]
        return if (s.dataSaver) minOf(base, 720) else base
    }

    /** تقدير حجم التنزيل بالبايت لنطاق واحد (تقريبي، من معدلات البت المعلنة) */
    fun estimateBytes(info: YtInfo, startMs: Long, endMs: Long, maxH: Int, saver: Boolean): Long {
        val secs = (endMs - startMs) / 1000.0
        val fs = info.json.optJSONArray("formats") ?: return 0L
        var vBest: JSONObject? = null
        var aBest: JSONObject? = null
        fun rate(f: JSONObject): Double {
            val tbr = f.optDouble("tbr", 0.0)
            if (tbr > 0) return tbr * 125.0
            val fsz = f.optDouble("filesize", f.optDouble("filesize_approx", 0.0))
            return if (fsz > 0 && info.durationMs > 0) fsz / (info.durationMs / 1000.0) else 0.0
        }
        for (i in 0 until fs.length()) {
            val f = fs.getJSONObject(i)
            val vc = f.optString("vcodec", "none")
            val ac = f.optString("acodec", "none")
            val h = f.optInt("height", 0)
            if (vc != "none" && h in 1..maxH) {
                val cur = vBest
                val avc = vc.startsWith("avc1")
                val curAvc = cur?.optString("vcodec", "")?.startsWith("avc1") == true
                if (cur == null || (avc && !curAvc) || (avc == curAvc && h > cur.optInt("height", 0)) ||
                    (avc == curAvc && h == cur.optInt("height", 0) && rate(f) > rate(cur))) vBest = f
            } else if (vc == "none" && ac != "none") {
                val abr = f.optDouble("abr", f.optDouble("tbr", 0.0))
                if (saver && abr > 130) continue
                val cur = aBest
                if (cur == null || abr > cur.optDouble("abr", cur.optDouble("tbr", 0.0))) aBest = f
            }
        }
        val v = vBest ?: return 0L
        var bps = rate(v)
        if (v.optString("acodec", "none") == "none" && aBest != null) bps += rate(aBest)
        return (bps * secs * 1.05).toLong()
    }

    /** يعمل على خيط خلفي. يرمي UserError برسالة مفهومة */
    fun downloadSection(
        ctx: Context, url: String, startMs: Long, endMs: Long, maxHeight: Int, saver: Boolean,
        outDir: File, tag: String, processId: String, onProgress: (Float) -> Unit
    ): DlResult {
        cancelled = false
        outDir.mkdirs()
        initOrThrow(ctx)
        val h = maxHeight
        val audio = if (saver) "ba[ext=m4a][abr<=130]/ba[ext=m4a]" else "ba[ext=m4a]"
        val fmt = "bv*[vcodec^=avc1][height<=$h]+$audio/b[ext=mp4][height<=$h]/bv*[height<=$h]+ba/b[height<=$h]/b"
        var forced = true
        var updated = false
        while (true) {
            if (cancelled) throw CancellationException()
            outDir.listFiles()?.filter { it.name.startsWith("$tag.") }?.forEach { it.delete() }
            try {
                val req = YoutubeDLRequest(url)
                req.addOption("-f", fmt)
                req.addOption("--download-sections", "*${sec(startMs)}-${sec(endMs)}")
                if (forced) req.addOption("--force-keyframes-at-cuts")
                req.addOption("--merge-output-format", "mp4")
                req.addOption("--no-playlist")
                req.addOption("-o", File(outDir, "$tag.%(ext)s").absolutePath)
                YoutubeDL.getInstance().execute(req, processId) { p, _, _ -> onProgress((p / 100f).coerceIn(0f, 1f)) }
                val f = outDir.listFiles()
                    ?.filter { it.name.startsWith("$tag.") && it.extension in listOf("mp4", "mkv", "webm", "m4v") }
                    ?.maxByOrNull { it.length() }
                if (f == null || f.length() == 0L)
                    throw UserError(tr("The download produced no file.", "لم ينتج عن التنزيل أي ملف."))
                return DlResult(f, forced)
            } catch (e: CancellationException) {
                throw e
            } catch (e: UserError) {
                throw e
            } catch (e: Throwable) {
                if (cancelled) throw CancellationException()
                val m = e.message ?: e.javaClass.simpleName
                val known = accessProblem(m)
                if (known != null) throw UserError(known)
                if (forced) { forced = false; continue }
                if (!updated) {
                    updated = true
                    try { YoutubeDL.getInstance().updateYoutubeDL(ctx.applicationContext) } catch (_: Throwable) {}
                    continue
                }
                throw UserError(tr("Download failed: ", "فشل التنزيل: ") + m.take(300))
            }
        }
    }
}
