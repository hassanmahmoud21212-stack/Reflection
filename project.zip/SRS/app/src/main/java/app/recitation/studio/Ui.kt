package app.recitation.studio

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** ألوان Apple Human Interface Guidelines (system colors) */
class Hig(val dark: Boolean) {
    val bg = if (dark) Color(0xFF000000) else Color(0xFFF2F2F7)
    val card = if (dark) Color(0xFF1C1C1E) else Color(0xFFFFFFFF)
    val label = if (dark) Color(0xFFFFFFFF) else Color(0xFF000000)
    val secondary = if (dark) Color(0x99EBEBF5) else Color(0x993C3C43)
    val separator = if (dark) Color(0xFF38383A) else Color(0xFFC6C6C8)
    val blue = if (dark) Color(0xFF0A84FF) else Color(0xFF007AFF)
    val green = if (dark) Color(0xFF30D158) else Color(0xFF34C759)
    val red = if (dark) Color(0xFFFF453A) else Color(0xFFFF3B30)
    val fill = if (dark) Color(0xFF2C2C2E) else Color(0xFFE5E5EA)
    val segSel = if (dark) Color(0xFF636366) else Color(0xFFFFFFFF)
}

val LocalHig = staticCompositionLocalOf { Hig(false) }

@Composable
fun HigTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val h = remember(dark) { Hig(dark) }
    val scheme = if (dark) darkColorScheme(primary = h.blue, background = h.bg, surface = h.card, onSurface = h.label)
    else lightColorScheme(primary = h.blue, background = h.bg, surface = h.card, onSurface = h.label)
    CompositionLocalProvider(LocalHig provides h) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

/** نقرة بدون موجة (ripple) كما في iOS */
@Composable
fun Modifier.tap(onClick: () -> Unit): Modifier =
    this.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)

@Composable
fun Group(header: String? = null, footer: String? = null, content: @Composable ColumnScope.() -> Unit) {
    val h = LocalHig.current
    Column(Modifier.fillMaxWidth().padding(top = 22.dp)) {
        if (header != null) {
            Text(header.uppercase(), color = h.secondary, fontSize = 13.sp,
                modifier = Modifier.padding(start = 16.dp, bottom = 6.dp))
        }
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(h.card), content = content)
        if (footer != null) {
            Text(footer, color = h.secondary, fontSize = 13.sp,
                modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 6.dp))
        }
    }
}

@Composable
fun Sep() {
    val h = LocalHig.current
    Box(Modifier.fillMaxWidth().padding(start = 16.dp).height(0.5.dp).background(h.separator))
}

@Composable
fun Cell(modifier: Modifier = Modifier, content: @Composable RowScope.() -> Unit) {
    Row(
        modifier.fillMaxWidth().heightIn(min = 44.dp).padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content
    )
}

@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val h = LocalHig.current
    Row(
        Modifier.fillMaxWidth().height(34.dp).clip(RoundedCornerShape(9.dp)).background(h.fill).padding(2.dp)
    ) {
        options.forEachIndexed { i, label ->
            val sel = i == selected
            Box(
                Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(7.dp))
                    .background(if (sel) h.segSel else Color.Transparent)
                    .tap { onSelect(i) },
                contentAlignment = Alignment.Center
            ) {
                Text(label, fontSize = 13.sp, color = h.label, maxLines = 1,
                    fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal)
            }
        }
    }
}

@Composable
fun SegmentedCell(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Box(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp)) {
        Segmented(options, selected, onSelect)
    }
}

@Composable
fun IosSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    val h = LocalHig.current
    Switch(
        checked = checked, onCheckedChange = onChange,
        colors = SwitchDefaults.colors(
            checkedThumbColor = Color.White, checkedTrackColor = h.green, checkedBorderColor = Color.Transparent,
            uncheckedThumbColor = Color.White, uncheckedTrackColor = h.fill, uncheckedBorderColor = Color.Transparent
        )
    )
}

@Composable
fun SliderCell(label: String, display: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    val h = LocalHig.current
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = h.label, fontSize = 17.sp)
            Text(display, color = h.secondary, fontSize = 17.sp)
        }
        Slider(
            value = value, onValueChange = onChange, valueRange = range,
            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = h.blue, inactiveTrackColor = h.fill)
        )
    }
}

@Composable
fun Field(value: String, placeholder: String, modifier: Modifier = Modifier, singleLine: Boolean = true, onChange: (String) -> Unit) {
    val h = LocalHig.current
    BasicTextField(
        value = value, onValueChange = onChange, singleLine = singleLine, modifier = modifier,
        textStyle = TextStyle(color = h.label, fontSize = 17.sp),
        cursorBrush = SolidColor(h.blue),
        decorationBox = { inner ->
            Box(contentAlignment = Alignment.CenterStart) {
                if (value.isEmpty()) Text(placeholder, color = h.secondary, fontSize = 17.sp)
                inner()
            }
        }
    )
}

@Composable
fun BigButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, filled: Boolean = true, onClick: () -> Unit) {
    val h = LocalHig.current
    Box(
        modifier.height(50.dp).clip(RoundedCornerShape(14.dp))
            .background(if (!enabled) h.fill else if (filled) h.blue else h.card)
            .tap { if (enabled) onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
            color = if (!enabled) h.secondary else if (filled) Color.White else h.blue)
    }
}

