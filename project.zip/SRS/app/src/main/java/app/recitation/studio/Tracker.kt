package app.recitation.studio

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.util.Arrays
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.roundToInt

/** نتيجة التتبع: مواضع الوجه (نسب 0..1) على محور الزمن النسبي للمقطع */
class TrackResult(
    val tUs: LongArray,
    val cx: FloatArray,
    val cy: FloatArray,
    private val cut: BooleanArray,
    val faceW: Float,
    val detected: Int,
    val samples: Int
) {
    fun valueAt(t: Long): Pair<Float, Float> {
        if (tUs.isEmpty()) return 0.5f to 0.5f
        var i = Arrays.binarySearch(tUs, t)
        if (i < 0) i = -i - 2
        if (i < 0) return cx[0] to cy[0]
        if (i >= tUs.size - 1) return cx[tUs.size - 1] to cy[tUs.size - 1]
        val t0 = tUs[i]
        val t1 = tUs[i + 1]
        if (cut[i + 1]) {
            return if (t < (t0 + t1) / 2) cx[i] to cy[i] else cx[i + 1] to cy[i + 1]
        }
        val f = (t - t0).toFloat() / (t1 - t0).toFloat()
        return (cx[i] + (cx[i + 1] - cx[i]) * f) to (cy[i] + (cy[i + 1] - cy[i]) * f)
    }
}

object Tracker {
    private const val STEP_MS = 300L

    private data class Fc(val x: Float, val y: Float, val w: Float)

    /** أبعاد الفيديو بعد تطبيق الدوران */
    fun videoSize(ctx: Context, uri: Uri): Pair<Int, Int> {
        val m = MediaMetadataRetriever()
        try {
            m.setDataSource(ctx, uri)
            var w = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            var h = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (w <= 0 || h <= 0) throw UserError(tr("Could not read the video size.", "تعذّرت قراءة أبعاد الفيديو."))
            if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
            return w to h
        } finally {
            m.release()
        }
    }

    fun durationMs(ctx: Context, uri: Uri): Long {
        val m = MediaMetadataRetriever()
        try {
            m.setDataSource(ctx, uri)
            return m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } finally {
            m.release()
        }
    }

    /** يعمل على خيط خلفي (غير الرئيسي) */
    fun analyze(
        ctx: Context, uri: Uri, startMs: Long, endMs: Long, subject: Int,
        onProgress: (Float) -> Unit
    ): TrackResult {
        val (srcW, srcH) = videoSize(ctx, uri)
        val mmr = MediaMetadataRetriever()
        val detector = FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .setMinFaceSize(0.08f)
                .build()
        )
        try {
            mmr.setDataSource(ctx, uri)
            val dstW = 640
            val dstH = (dstW.toFloat() * srcH / srcW).roundToInt().coerceAtLeast(2)
            val n = ((endMs - startMs) / STEP_MS).toInt() + 1
            val tUs = LongArray(n) { it * STEP_MS * 1000 }
            val cx = FloatArray(n) { Float.NaN }
            val cy = FloatArray(n) { Float.NaN }
            val cut = BooleanArray(n)
            val widths = ArrayList<Float>()
            var prevThumb: IntArray? = null
            var prev: Fc? = null
            var detected = 0

            for (i in 0 until n) {
                onProgress(i.toFloat() / n)
                val tMs = minOf(startMs + i * STEP_MS, endMs - 1)
                val bmp = mmr.getScaledFrameAtTime(tMs * 1000, MediaMetadataRetriever.OPTION_CLOSEST, dstW, dstH)
                    ?: continue

                // اكتشاف قطع المشهد (فرق سطوع كبير بين عيّنتين)
                val th = thumb(bmp)
                val pt = prevThumb
                if (pt != null && i > 0) {
                    var d = 0L
                    for (k in th.indices) d += abs(th[k] - pt[k])
                    if (d / th.size > 34) { cut[i] = true; prev = null }
                }
                prevThumb = th

                val faces = Tasks.await(detector.process(InputImage.fromBitmap(bmp, 0)))
                val cands = faces.map {
                    val b = it.boundingBox
                    Fc(b.exactCenterX() / bmp.width, b.exactCenterY() / bmp.height, b.width().toFloat() / bmp.width)
                }
                val p = prev
                val pick: Fc? = when {
                    cands.isEmpty() -> null
                    subject == 1 -> cands.minByOrNull { it.x }
                    subject == 2 -> cands.maxByOrNull { it.x }
                    p != null -> cands.minByOrNull { hypot(it.x - p.x, it.y - p.y) - 0.5f * it.w }
                    else -> cands.maxByOrNull { it.w }
                }
                if (pick != null) {
                    cx[i] = pick.x; cy[i] = pick.y
                    widths.add(pick.w)
                    prev = pick
                    detected++
                }
                bmp.recycle()
            }
            onProgress(1f)

            // معالجة كل لقطة على حدة: ملء الفراغات ← وسيط ← منطقة سكون ← تنعيم غاوسي
            val starts = (0 until n).filter { it == 0 || cut[it] } + n
            for (si in 0 until starts.size - 1) {
                val a = starts[si]
                val b = starts[si + 1]
                processSegment(cx, a, b, 0.5f)
                processSegment(cy, a, b, 0.45f)
            }
            widths.sort()
            val faceW = if (widths.isEmpty()) 0.2f else widths[widths.size / 2]
            return TrackResult(tUs, cx, cy, cut, faceW, detected, n)
        } finally {
            mmr.release()
            detector.close()
        }
    }

    private fun thumb(b: Bitmap): IntArray {
        val t = Bitmap.createScaledBitmap(b, 16, 16, true)
        val px = IntArray(256)
        t.getPixels(px, 0, 16, 0, 0, 16, 16)
        if (t !== b) t.recycle()
        return IntArray(256) {
            val p = px[it]
            (((p shr 16) and 255) * 3 + ((p shr 8) and 255) * 6 + (p and 255)) / 10
        }
    }

    private fun processSegment(v: FloatArray, a: Int, b: Int, fallback: Float) {
        val valid = (a until b).filter { !v[it].isNaN() }
        if (valid.isEmpty()) {
            for (i in a until b) v[i] = fallback
            return
        }
        // ملء الفراغات بالاستيفاء الخطي
        for (i in a until b) {
            if (!v[i].isNaN()) continue
            val l = valid.lastOrNull { it < i }
            val r = valid.firstOrNull { it > i }
            v[i] = when {
                l == null -> v[r!!]
                r == null -> v[l]
                else -> v[l] + (v[r] - v[l]) * (i - l).toFloat() / (r - l).toFloat()
            }
        }
        // مرشّح وسيط (5)
        val src = v.copyOfRange(a, b)
        val len = b - a
        for (i in 0 until len) {
            val w = FloatArray(5) { src[(i + it - 2).coerceIn(0, len - 1)] }
            w.sort()
            v[a + i] = w[2]
        }
        // منطقة سكون (hysteresis)
        var held = v[a]
        for (i in a until b) {
            if (abs(v[i] - held) > 0.015f) held = v[i]
            v[i] = held
        }
        // تنعيم غاوسي
        val s2 = v.copyOfRange(a, b)
        val k = FloatArray(9) { exp(-((it - 4) * (it - 4)).toFloat() / 8f) }
        val ks = k.sum()
        for (i in 0 until len) {
            var acc = 0f
            for (j in 0 until 9) acc += k[j] * s2[(i + j - 4).coerceIn(0, len - 1)]
            v[a + i] = acc / ks
        }
    }
}
