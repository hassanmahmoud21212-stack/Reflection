package app.recitation.studio

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.view.TextureView
import androidx.annotation.OptIn
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private fun localFrame(ctx: Context, uri: String): Bitmap? {
    val m = MediaMetadataRetriever()
    return try {
        m.setDataSource(ctx, Uri.parse(uri))
        m.getScaledFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 320, 180)
    } catch (_: Throwable) {
        null
    } finally {
        m.release()
    }
}

/** صورة مصغّرة: رابط من YouTube أو إطار من فيديو محلي */
@Composable
fun Thumb(src: Source, modifier: Modifier) {
    val h = LocalHig.current
    val ctx = LocalContext.current
    if (src.thumb.isNotEmpty()) {
        AsyncImage(model = src.thumb, contentDescription = null, contentScale = ContentScale.Crop, modifier = modifier)
    } else if (!src.isYoutube && src.uri.isNotEmpty()) {
        val bmp: ImageBitmap? by produceState<ImageBitmap?>(null, src.uri) {
            value = withContext(Dispatchers.IO) { localFrame(ctx, src.uri)?.asImageBitmap() }
        }
        val b = bmp
        if (b != null) Image(b, null, contentScale = ContentScale.Crop, modifier = modifier)
        else Box(modifier.background(h.fill))
    } else {
        Box(modifier.background(h.fill))
    }
}

/** معاينة + تحديد البداية/النهاية وإضافة مقطع. استدعِها داخل key(src.uri) */
@OptIn(UnstableApi::class)
@Composable
fun SourcePreview(src: Source, flipH: Boolean, flipV: Boolean, onAddClip: (Long, Long) -> Unit) {
    val h = LocalHig.current
    val ctx = LocalContext.current
    val holder = remember { arrayOfNulls<ExoPlayer>(1) }
    var player by remember { mutableStateOf<ExoPlayer?>(null) }
    var started by remember { mutableStateOf(!src.isYoutube) }
    var loading by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }
    var aspect by remember { mutableFloatStateOf(16f / 9f) }
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(src.durationMs) }
    var playing by remember { mutableStateOf(false) }
    var markA by remember { mutableLongStateOf(-1L) }
    var markB by remember { mutableLongStateOf(-1L) }

    LaunchedEffect(started) {
        if (!started || player != null) return@LaunchedEffect
        loading = true
        try {
            val pl: ExoPlayer
            val media: String
            if (src.isYoutube) {
                val ps = withContext(Dispatchers.IO) { YtDl.previewStream(ctx, src.uri) }
                val f = DefaultHttpDataSource.Factory().setDefaultRequestProperties(ps.second)
                pl = ExoPlayer.Builder(ctx).setMediaSourceFactory(DefaultMediaSourceFactory(f)).build()
                media = ps.first
            } else {
                pl = ExoPlayer.Builder(ctx).build()
                media = src.uri
            }
            pl.addListener(object : Player.Listener {
                override fun onVideoSizeChanged(videoSize: VideoSize) {
                    if (videoSize.width > 0 && videoSize.height > 0)
                        aspect = videoSize.width * videoSize.pixelWidthHeightRatio / videoSize.height
                }
                override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
                override fun onPlayerError(error: PlaybackException) { err = error.message ?: "playback error" }
            })
            pl.setMediaItem(MediaItem.fromUri(media))
            pl.playWhenReady = src.isYoutube
            pl.prepare()
            holder[0] = pl
            player = pl
        } catch (e: Throwable) {
            err = e.message ?: e.javaClass.simpleName
            started = false
        }
        loading = false
    }
    DisposableEffect(Unit) { onDispose { holder[0]?.release(); holder[0] = null } }
    LaunchedEffect(player) {
        val pl = player ?: return@LaunchedEffect
        while (true) {
            pos = pl.currentPosition
            val d = pl.duration
            if (d != C.TIME_UNSET && d > 0) dur = d
            delay(150)
        }
    }

    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(aspect).clip(RoundedCornerShape(12.dp)).background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            val pl = player
            if (pl != null) {
                AndroidView(
                    factory = { c -> TextureView(c).also { tv -> pl.setVideoTextureView(tv) } },
                    modifier = Modifier.fillMaxSize().graphicsLayer(scaleX = if (flipH) -1f else 1f, scaleY = if (flipV) -1f else 1f)
                )
            } else {
                Thumb(src, Modifier.fillMaxSize())
                Box(
                    Modifier.size(56.dp).clip(CircleShape).background(Color(0x88000000)).tap { if (!loading) { err = null; started = true } },
                    contentAlignment = Alignment.Center
                ) {
                    if (loading) CircularProgressIndicator(color = Color.White, modifier = Modifier.size(28.dp))
                    else Text("▶", color = Color.White, fontSize = 22.sp)
                }
            }
        }
        if (src.isYoutube && player == null)
            Text(tr("Preview streams a low-quality (≤480p) copy and uses some data.", "المعاينة تبثّ نسخة منخفضة الجودة (≤480p) وتستهلك بعض البيانات."), color = h.secondary, fontSize = 13.sp)
        err?.let { Text(it.take(160), color = h.red, fontSize = 13.sp) }

        val pl = player
        if (pl != null) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(40.dp).clip(CircleShape).background(h.fill).tap { if (pl.isPlaying) pl.pause() else pl.play() }, contentAlignment = Alignment.Center) {
                    Text(if (playing) "❚❚" else "▶", color = h.label, fontSize = 14.sp)
                }
                Slider(
                    value = pos.toFloat().coerceIn(0f, dur.coerceAtLeast(1L).toFloat()),
                    onValueChange = { v -> pos = v.toLong(); pl.seekTo(v.toLong()) },
                    valueRange = 0f..dur.coerceAtLeast(1L).toFloat(),
                    colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = h.blue, inactiveTrackColor = h.fill),
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                )
                Text(fmtTime(pos) + " / " + fmtTime(dur), color = h.secondary, fontSize = 12.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MarkButton("[ " + (if (markA >= 0) fmtPrecise(markA) else tr("Start", "بداية")), Modifier.weight(1f)) { markA = pos }
                MarkButton((if (markB >= 0) fmtPrecise(markB) else tr("End", "نهاية")) + " ]", Modifier.weight(1f)) { markB = pos }
                MarkButton("＋ " + tr("Clip", "مقطع"), Modifier.weight(1f), enabled = markA >= 0 && markB > markA, filled = true) {
                    onAddClip(markA, markB); markA = -1; markB = -1
                }
            }
        }
    }
}

@Composable
private fun MarkButton(text: String, modifier: Modifier, enabled: Boolean = true, filled: Boolean = false, onClick: () -> Unit) {
    val h = LocalHig.current
    Box(
        modifier.clip(RoundedCornerShape(10.dp))
            .background(if (!enabled) h.fill else if (filled) h.blue else h.fill)
            .tap { if (enabled) onClick() }.padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1,
            color = if (!enabled) h.secondary else if (filled) Color.White else h.label)
    }
}
