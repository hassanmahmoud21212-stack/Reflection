package app.recitation.studio

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.DateFormat
import java.util.Date

@Composable
fun App(vm: MainVM) {
    val h = LocalHig.current
    val projects by vm.projects.collectAsState()
    val ex by vm.exportUi.collectAsState()
    val p = projects.firstOrNull { it.id == vm.openId }
    Box(Modifier.fillMaxSize().background(h.bg)) {
        if (p == null) {
            HomeScreen(vm, projects)
        } else {
            BackHandler { vm.openId = null }
            EditorScreen(vm, p)
        }
        if (ex.visible) ExportSheet(vm, ex)
    }
}

// ======================= الرئيسية | Home =======================

@Composable
fun HomeScreen(vm: MainVM, projects: List<Project>) {
    val h = LocalHig.current
    var query by remember { mutableStateOf("") }
    var sort by remember { mutableIntStateOf(0) }
    var toDelete by remember { mutableStateOf<Project?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) vm.createFromVideo(uri)
    }
    val sortNames = listOf(tr("Updated", "الأحدث تعديلًا"), tr("Name", "الاسم"), tr("Created", "الإنشاء"))
    val shown = projects.filter { it.name.contains(query, ignoreCase = true) }.let { l ->
        when (sort) {
            1 -> l.sortedBy { it.name.lowercase() }
            2 -> l.sortedByDescending { it.created }
            else -> l.sortedByDescending { it.updated }
        }
    }

    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 24.dp, bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column {
                Text(tr("Welcome Back!", "أهلًا بعودتك!"), color = h.label, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                Text(tr("Let's create something amazing today.", "هيا نصنع شيئًا رائعًا اليوم."), color = h.secondary, fontSize = 17.sp)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                BigButton("＋  " + tr("New Project", "مشروع جديد"), Modifier.weight(1f)) { vm.newProject() }
                Box(
                    Modifier.size(50.dp).clip(RoundedCornerShape(14.dp)).background(h.card)
                        .tap { picker.launch(arrayOf("video/*")) },
                    contentAlignment = Alignment.Center
                ) { Text("↥", color = h.blue, fontSize = 24.sp) }
            }
        }
        item {
            Text(tr("All Projects", "كل المشاريع"), color = h.label, fontSize = 28.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 8.dp))
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Row(
                    Modifier.weight(1f).height(44.dp).clip(RoundedCornerShape(12.dp)).background(h.card).padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Search, contentDescription = null, tint = h.secondary)
                    Spacer(Modifier.width(8.dp))
                    BasicTextField(
                        value = query, onValueChange = { query = it }, singleLine = true,
                        textStyle = TextStyle(color = h.label, fontSize = 17.sp),
                        cursorBrush = SolidColor(h.blue),
                        decorationBox = { inner ->
                            Box(contentAlignment = Alignment.CenterStart) {
                                if (query.isEmpty()) Text(tr("Search projects…", "ابحث في المشاريع…"), color = h.secondary, fontSize = 17.sp)
                                inner()
                            }
                        }
                    )
                }
                Box(
                    Modifier.height(44.dp).clip(RoundedCornerShape(12.dp)).background(h.card)
                        .tap { sort = (sort + 1) % 3 }.padding(horizontal = 12.dp),
                    contentAlignment = Alignment.Center
                ) { Text("⇅ " + sortNames[sort], color = h.blue, fontSize = 13.sp) }
            }
        }
        if (shown.isEmpty()) {
            item {
                Text(
                    tr("No projects yet. Tap “New Project” to start.", "لا توجد مشاريع بعد. اضغط «مشروع جديد» للبدء."),
                    color = h.secondary, fontSize = 15.sp, modifier = Modifier.padding(vertical = 24.dp)
                )
            }
        }
        items(shown, key = { it.id }) { p ->
            ProjectCard(p, onOpen = { vm.openId = p.id }, onDuplicate = { vm.duplicate(p) }, onDelete = { toDelete = p })
        }
    }

    val del = toDelete
    if (del != null) {
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text(tr("Delete project?", "حذف المشروع؟")) },
            text = { Text(tr("“${del.name}” will be removed. Exported videos stay in your gallery.", "سيُحذف «${del.name}». تبقى الفيديوهات المصدّرة في المعرض.")) },
            confirmButton = { TextButton(onClick = { vm.delete(del.id); toDelete = null }) { Text(tr("Delete", "حذف"), color = h.red) } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text(tr("Cancel", "إلغاء")) } }
        )
    }
}

@Composable
fun ProjectCard(p: Project, onOpen: () -> Unit, onDuplicate: () -> Unit, onDelete: () -> Unit) {
    val h = LocalHig.current
    var menu by remember { mutableStateOf(false) }
    val (stText, stColor) = when (p.status()) {
        2 -> tr("Exported", "تم التصدير") to h.green
        1 -> tr("Ready", "جاهز") to h.blue
        else -> tr("Not Set", "غير مهيأ") to h.secondary
    }
    val df = DateFormat.getDateInstance(DateFormat.SHORT)
    val clipCount = p.clips.count { it.start.isNotBlank() && it.end.isNotBlank() }

    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(h.card)) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Text(p.name, color = h.blue, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Box(Modifier.padding(top = 7.dp).size(10.dp).clip(CircleShape).background(stColor))
                Spacer(Modifier.width(8.dp))
                Text(stText, color = h.label, fontSize = 15.sp)
            }
            Spacer(Modifier.height(4.dp))
            InfoLine(tr("Source", "المصدر"), p.sourceName.ifEmpty { tr("not set", "غير محدد") })
            InfoLine(tr("Duration", "المدة"), fmtTime(p.durationMs))
            InfoLine(tr("Clips", "المقاطع"), if (clipCount == 0) tr("none", "لا يوجد") else clipCount.toString())
        }
        Box(Modifier.fillMaxWidth().height(0.5.dp).background(h.separator))
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(tr("Created: ", "أُنشئ: ") + df.format(Date(p.created)), color = h.secondary, fontSize = 15.sp)
                Text(tr("Updated: ", "عُدّل: ") + df.format(Date(p.updated)), color = h.secondary, fontSize = 15.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BigButton(tr("Open", "فتح"), Modifier.weight(1f).height(48.dp)) { onOpen() }
                Box(
                    Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(h.fill).tap { menu = true },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.MoreVert, contentDescription = null, tint = h.label)
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text(tr("Duplicate", "نسخ")) }, onClick = { menu = false; onDuplicate() })
                        DropdownMenuItem(text = { Text(tr("Delete", "حذف"), color = h.red) }, onClick = { menu = false; onDelete() })
                    }
                }
            }
        }
    }
}

@Composable
fun InfoLine(label: String, value: String) {
    val h = LocalHig.current
    Row {
        Text("$label: ", color = h.secondary, fontSize = 17.sp)
        Text(value, color = h.label, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

// ======================= المحرر | Editor =======================

@Composable
fun EditorScreen(vm: MainVM, p: Project) {
    val h = LocalHig.current
    val s = p.settings
    fun upd(f: (Settings) -> Settings) = vm.update(p.copy(settings = f(s)))
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) vm.setSource(p.id, uri)
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
        // شريط التنقل
        Row(Modifier.fillMaxWidth().height(48.dp).padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("‹ " + tr("Projects", "المشاريع"), color = h.blue, fontSize = 17.sp, modifier = Modifier.tap { vm.openId = null }.padding(8.dp))
            Spacer(Modifier.weight(1f))
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            Text(p.name.ifEmpty { tr("Project", "مشروع") }, color = h.label, fontSize = 34.sp, fontWeight = FontWeight.Bold, maxLines = 1)

            Group(tr("Project", "المشروع")) {
                Cell {
                    Text(tr("Name", "الاسم"), color = h.label, fontSize = 17.sp, modifier = Modifier.width(90.dp))
                    Field(p.name, tr("Project name", "اسم المشروع"), Modifier.weight(1f)) { vm.update(p.copy(name = it)) }
                }
            }

            Group(
                tr("Source", "المصدر"),
                tr("Pick a video saved on your phone. (YouTube download is not built into this app — save the video first.)",
                    "اختر فيديو محفوظًا على هاتفك. (تنزيل YouTube غير مدمج في التطبيق — احفظ الفيديو أولًا.)")
            ) {
                Cell(Modifier.tap { picker.launch(arrayOf("video/*")) }) {
                    Text(tr("Video", "الفيديو"), color = h.label, fontSize = 17.sp)
                    Spacer(Modifier.weight(1f))
                    Text(
                        if (p.sourceName.isEmpty()) tr("Choose…", "اختر…") else p.sourceName,
                        color = if (p.sourceName.isEmpty()) h.blue else h.secondary, fontSize = 17.sp, maxLines = 1,
                        modifier = Modifier.weight(2f, fill = false)
                    )
                    Text("  ›", color = h.secondary, fontSize = 17.sp)
                }
                if (p.durationMs > 0) {
                    Sep()
                    Cell {
                        Text(tr("Length", "المدة"), color = h.label, fontSize = 17.sp)
                        Spacer(Modifier.weight(1f))
                        Text(fmtTime(p.durationMs), color = h.secondary, fontSize = 17.sp)
                    }
                }
            }

            Group(
                tr("Clips", "المقاطع"),
                tr("Format MM:SS or HH:MM:SS (decimals allowed: 01:23.5). Leave a row empty to skip it. Each clip is exported as its own file.",
                    "الصيغة MM:SS أو HH:MM:SS (يُقبل كسر مثل 01:23.5). اترك السطر فارغًا لتخطيه. كل مقطع يُصدَّر في ملف مستقل.")
            ) {
                p.clips.forEachIndexed { i, c ->
                    if (i > 0) Sep()
                    Cell {
                        Text("${i + 1}", color = h.secondary, fontSize = 17.sp, modifier = Modifier.width(24.dp))
                        Field(c.start, "00:00", Modifier.weight(1f)) { v ->
                            vm.update(p.copy(clips = p.clips.toMutableList().also { it[i] = c.copy(start = v) }))
                        }
                        Text("→", color = h.secondary, fontSize = 17.sp, modifier = Modifier.padding(horizontal = 8.dp))
                        Field(c.end, "00:30", Modifier.weight(1f)) { v ->
                            vm.update(p.copy(clips = p.clips.toMutableList().also { it[i] = c.copy(end = v) }))
                        }
                    }
                }
            }

            Group(tr("Format", "الاتجاه")) {
                SegmentedCell(
                    listOf(tr("Portrait 9:16", "طولي 9:16"), tr("Landscape 16:9", "عرضي 16:9"), tr("Original", "الأصل")),
                    s.orientation
                ) { v -> upd { it.copy(orientation = v) } }
            }

            if (s.orientation != 2) {
                Group(
                    tr("Framing", "التأطير"),
                    if (s.framing == 0) tr("Face detection runs on-device. It can pick the wrong person in crowded shots — use Left/Right or Manual then.",
                        "كشف الوجه يعمل على الجهاز. قد يختار شخصًا خطأ عند التزاحم — استخدم الأيسر/الأيمن أو اليدوي حينها.") else null
                ) {
                    SegmentedCell(
                        listOf(tr("Auto track", "تتبع تلقائي"), tr("Center", "منتصف"), tr("Manual", "يدوي")),
                        s.framing
                    ) { v -> upd { it.copy(framing = v) } }
                    if (s.framing == 0) {
                        Sep()
                        SegmentedCell(listOf(tr("Any person", "أي شخص"), tr("Left", "الأيسر"), tr("Right", "الأيمن")), s.subject) { v -> upd { it.copy(subject = v) } }
                        Sep()
                        SegmentedCell(listOf(tr("Wide", "واسع"), tr("Medium", "متوسط"), tr("Close", "قريب")), s.faceSize) { v -> upd { it.copy(faceSize = v) } }
                    }
                    if (s.framing == 2) {
                        Sep()
                        SliderCell(tr("Horizontal", "أفقي"), "${s.manualX.toInt()}%", s.manualX, 0f..100f) { v -> upd { it.copy(manualX = v) } }
                        Sep()
                        SliderCell(tr("Vertical", "عمودي"), "${s.manualY.toInt()}%", s.manualY, 0f..100f) { v -> upd { it.copy(manualY = v) } }
                        Sep()
                        SliderCell(tr("Zoom", "التكبير"), "×" + String.format("%.1f", s.manualZoom), s.manualZoom, 1f..3f) { v -> upd { it.copy(manualZoom = v) } }
                    }
                }
            }

            val qNames = listOf(tr("Best (source detail)", "الأفضل (تفاصيل المصدر)"), "2160p", "1440p", "1080p", "720p", "480p")
            var qMenu by remember { mutableStateOf(false) }
            Group(
                tr("Quality", "الجودة"),
                tr("The number is the shorter side. Higher than the source detail means upscaling.", "الرقم = الضلع الأقصر. أعلى من تفاصيل المصدر يعني تكبيرًا.")
            ) {
                Cell(Modifier.tap { qMenu = true }) {
                    Text(tr("Resolution", "الدقة"), color = h.label, fontSize = 17.sp)
                    Spacer(Modifier.weight(1f))
                    Box {
                        Text(qNames[s.quality] + "  ›", color = h.secondary, fontSize = 17.sp)
                        DropdownMenu(expanded = qMenu, onDismissRequest = { qMenu = false }) {
                            qNames.forEachIndexed { i, n ->
                                DropdownMenuItem(text = { Text(n) }, onClick = { qMenu = false; upd { it.copy(quality = i) } })
                            }
                        }
                    }
                }
            }

            Group(tr("Fade", "التلاشي")) {
                SegmentedCell(
                    listOf(tr("None", "بدون"), tr("In & Out", "دخول وخروج"), tr("In", "دخول"), tr("Out", "خروج")),
                    s.fadeMode
                ) { v -> upd { it.copy(fadeMode = v) } }
                if (s.fadeMode != 0) {
                    Sep()
                    SliderCell(tr("Duration", "المدة"), String.format("%.1f s", s.fadeSec), s.fadeSec, 0.2f..2f) { v -> upd { it.copy(fadeSec = v) } }
                    Sep()
                    Cell {
                        Text(tr("Fade audio", "تلاشي الصوت"), color = h.label, fontSize = 17.sp)
                        Spacer(Modifier.weight(1f))
                        IosSwitch(s.fadeAudio) { v -> upd { it.copy(fadeAudio = v) } }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
        Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
            BigButton(tr("Export", "تصدير"), Modifier.fillMaxWidth(), enabled = p.sourceUri.isNotEmpty()) { vm.startExport(p) }
        }
    }
}

// ======================= شاشة التصدير | Export sheet =======================

@Composable
fun ExportSheet(vm: MainVM, ex: ExportUi) {
    val h = LocalHig.current
    val ctx = LocalContext.current
    val view = LocalView.current
    DisposableEffect(ex.running) {
        view.keepScreenOn = ex.running
        onDispose { view.keepScreenOn = false }
    }
    Box(Modifier.fillMaxSize().background(Color(0x99000000)).tap { }, contentAlignment = Alignment.BottomCenter) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)).background(h.card)
                .navigationBarsPadding().padding(20.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            val title = when {
                ex.error != null -> tr("Couldn't export", "تعذّر التصدير")
                ex.running -> tr("Exporting…", "جارٍ التصدير…")
                else -> tr("Done", "اكتمل")
            }
            Text(title, color = h.label, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            if (ex.error != null) Text(ex.error, color = h.red, fontSize = 15.sp)
            if (ex.running) {
                Text(ex.stage, color = h.secondary, fontSize = 15.sp)
                LinearProgressIndicator(progress = { ex.progress.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth(), color = h.blue, trackColor = h.fill)
                Text(tr("Keep the app open until it finishes.", "أبقِ التطبيق مفتوحًا حتى ينتهي."), color = h.secondary, fontSize = 13.sp)
            }
            ex.results.forEach { (name, uri) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("✓ $name", color = h.label, fontSize = 15.sp, maxLines = 1, modifier = Modifier.weight(1f))
                    TextButton(onClick = {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "video/mp4"
                            putExtra(Intent.EXTRA_STREAM, Uri.parse(uri))
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        ctx.startActivity(Intent.createChooser(send, null))
                    }) { Text(tr("Share", "مشاركة"), color = h.blue) }
                }
            }
            if (!ex.running && ex.error == null && ex.results.isNotEmpty())
                Text(tr("Saved in Movies ▸ Smart Recitation Studio.", "حُفظت في Movies ▸ Smart Recitation Studio."), color = h.secondary, fontSize = 13.sp)
            ex.warnings.forEach { Text("⚠ $it", color = h.secondary, fontSize = 13.sp) }
            BigButton(if (ex.running) tr("Cancel", "إلغاء") else tr("Close", "إغلاق"), Modifier.fillMaxWidth(), filled = !ex.running) { vm.closeExport() }
        }
    }
}
