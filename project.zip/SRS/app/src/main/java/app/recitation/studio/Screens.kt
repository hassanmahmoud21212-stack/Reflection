package app.recitation.studio

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.key
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.text.DateFormat
import java.util.Date

@Composable
fun App(vm: MainVM) {
    val h = LocalHig.current
    val projects by vm.projects.collectAsState()
    val ex by ExportEngine.ui.collectAsState()
    val p = projects.firstOrNull { it.id == vm.openId }
    Box(Modifier.fillMaxSize().background(h.bg)) {
        if (p == null) {
            HomeScreen(vm, projects, ex)
        } else {
            BackHandler { vm.openId = null }
            EditorScreen(vm, p, ex)
        }
        if (vm.showExport && (ex.running || ex.finished)) ExportSheet(vm, ex)
    }
    if (vm.estimating) {
        AlertDialog(
            onDismissRequest = {}, confirmButton = {},
            title = { Text(tr("Estimating download size…", "جارٍ تقدير حجم التنزيل…")) },
            text = { Text(tr("Reading video info (tiny request, nothing is downloaded yet).", "قراءة معلومات الفيديو (طلب صغير، لم يبدأ أي تنزيل بعد).")) }
        )
    }
    val c = vm.confirm
    if (c != null) {
        AlertDialog(
            onDismissRequest = { vm.confirm = null },
            title = { Text(tr("Download ≈ ", "التنزيل ≈ ") + fmtBytes(c.bytes)) },
            text = {
                Text(
                    tr("${c.parts} YouTube part(s) at up to ${c.height}p. Only the clip ranges are downloaded, not the full videos.",
                        "${c.parts} جزء من YouTube بجودة حتى ${c.height}p. تُنزَّل نطاقات المقاطع فقط، وليس الفيديوهات كاملة.") +
                        (if (c.cellular) "\n\n" + tr("You're on mobile data.", "أنت تستخدم بيانات الجوال.") else "") +
                        (if (!c.project.settings.dataSaver) "\n\n" + tr("Tip: turn on Data saver to cap at 720p.", "نصيحة: فعّل «توفير البيانات» لتحديد 720p كحد أقصى.") else "")
                )
            },
            confirmButton = { TextButton(onClick = { vm.confirmExport() }) { Text(tr("Download & export", "نزّل وصدّر"), color = h.blue) } },
            dismissButton = { TextButton(onClick = { vm.confirm = null }) { Text(tr("Cancel", "إلغاء")) } }
        )
    }
    val m = vm.message
    if (m != null) {
        AlertDialog(
            onDismissRequest = { vm.message = null },
            text = { Text(m) },
            confirmButton = { TextButton(onClick = { vm.message = null }) { Text("OK") } }
        )
    }
}

// ======================= الرئيسية | Home =======================

@Composable
fun HomeScreen(vm: MainVM, projects: List<Project>, ex: ExportUi) {
    val h = LocalHig.current
    var query by remember { mutableStateOf("") }
    var sort by remember { mutableIntStateOf(0) }
    var toDelete by remember { mutableStateOf<Project?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) vm.createFromVideo(uri)
    }
    val sortNames = listOf(tr("Updated", "الأحدث تعديلًا"), tr("Name", "الاسم"), tr("Created", "الإنشاء"))
    val shown = projects.filter { it.name.contains(query, ignoreCase = true) }.let { l ->
        when (sort) {
            1 -> l.sortedBy { it.name.lowercase() }
            2 -> l.sortedByDescending { it.created }
            else -> l.sortedByDescending { it.updated }
        }
    }

    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 24.dp, bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column {
                Text(tr("Welcome Back!", "أهلًا بعودتك!"), color = h.label, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                Text(tr("Let's create something amazing today.", "هيا نصنع شيئًا رائعًا اليوم."), color = h.secondary, fontSize = 17.sp)
            }
        }
        if (ex.running || ex.finished) {
            item {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(h.card)
                        .tap { vm.showExport = true }.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (ex.running) tr("Exporting ", "جارٍ التصدير ") + ex.current + "  " + (ex.progress * 100).toInt() + "%"
                            else tr("Export finished", "انتهى التصدير"),
                            color = h.label, fontSize = 15.sp, fontWeight = FontWeight.SemiBold
                        )
                        if (ex.running && ex.queued.isNotEmpty())
                            Text(tr("${ex.queued.size} more in queue", "${ex.queued.size} في الطابور"), color = h.secondary, fontSize = 13.sp)
                    }
                    Text(tr("View", "عرض"), color = h.blue, fontSize = 15.sp)
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                BigButton("＋  " + tr("New Project", "مشروع جديد"), Modifier.weight(1f)) { vm.newProject() }
                Box(
                    Modifier.size(50.dp).clip(RoundedCornerShape(14.dp)).background(h.card)
                        .tap { picker.launch(arrayOf("video/*")) },
                    contentAlignment = Alignment.Center
                ) { Text("↥", color = h.blue, fontSize = 24.sp) }
            }
        }
        item {
            Text(tr("All Projects", "كل المشاريع"), color = h.label, fontSize = 28.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 8.dp))
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Row(
                    Modifier.weight(1f).height(44.dp).clip(RoundedCornerShape(12.dp)).background(h.card).padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Search, contentDescription = null, tint = h.secondary)
                    Spacer(Modifier.width(8.dp))
                    BasicTextField(
                        value = query, onValueChange = { query = it }, singleLine = true,
                        textStyle = TextStyle(color = h.label, fontSize = 17.sp),
                        cursorBrush = SolidColor(h.blue),
                        decorationBox = { inner ->
                            Box(contentAlignment = Alignment.CenterStart) {
                                if (query.isEmpty()) Text(tr("Search projects…", "ابحث في المشاريع…"), color = h.secondary, fontSize = 17.sp)
                                inner()
                            }
                        }
                    )
                }
                Box(
                    Modifier.height(44.dp).clip(RoundedCornerShape(12.dp)).background(h.card)
                        .tap { sort = (sort + 1) % 3 }.padding(horizontal = 12.dp),
                    contentAlignment = Alignment.Center
                ) { Text("⇅ " + sortNames[sort], color = h.blue, fontSize = 13.sp) }
            }
        }
        if (shown.isEmpty()) {
            item {
                Text(
                    tr("No projects yet. Tap “New Project” to start.", "لا توجد مشاريع بعد. اضغط «مشروع جديد» للبدء."),
                    color = h.secondary, fontSize = 15.sp, modifier = Modifier.padding(vertical = 24.dp)
                )
            }
        }
        items(shown, key = { it.id }) { p ->
            ProjectCard(p, onOpen = { vm.openId = p.id }, onDuplicate = { vm.duplicate(p) }, onDelete = { toDelete = p })
        }
    }

    val del = toDelete
    if (del != null) {
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text(tr("Delete project?", "حذف المشروع؟")) },
            text = { Text(tr("“${del.name}” will be removed. Exported videos stay in your gallery.", "سيُحذف «${del.name}». تبقى الفيديوهات المصدّرة في المعرض.")) },
            confirmButton = { TextButton(onClick = { vm.delete(del.id); toDelete = null }) { Text(tr("Delete", "حذف"), color = h.red) } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text(tr("Cancel", "إلغاء")) } }
        )
    }
}

@Composable
fun ProjectCard(p: Project, onOpen: () -> Unit, onDuplicate: () -> Unit, onDelete: () -> Unit) {
    val h = LocalHig.current
    var menu by remember { mutableStateOf(false) }
    val (stText, stColor) = when (p.status()) {
        2 -> tr("Exported", "تم التصدير") to h.green
        1 -> tr("Ready", "جاهز") to h.blue
        else -> tr("Not Set", "غير مهيأ") to h.secondary
    }
    val df = DateFormat.getDateInstance(DateFormat.SHORT)
    val clipCount = p.clips.count { it.start.isNotBlank() && it.end.isNotBlank() }

    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(h.card)) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Text(p.name, color = h.blue, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Box(Modifier.padding(top = 7.dp).size(10.dp).clip(CircleShape).background(stColor))
                Spacer(Modifier.width(8.dp))
                Text(stText, color = h.label, fontSize = 15.sp)
            }
            Spacer(Modifier.height(4.dp))
            if (p.sources.isNotEmpty())
                Thumb(p.sources.first(), Modifier.fillMaxWidth().height(120.dp).clip(RoundedCornerShape(10.dp)))
            InfoLine(tr("Source", "المصدر"), if (p.sources.isEmpty()) tr("not set", "غير محدد") else p.sources.first().name.ifEmpty { "…" } + (if (p.sources.size > 1) " +${p.sources.size - 1}" else ""))
            InfoLine(tr("Duration", "المدة"), fmtTime(p.sources.sumOf { it.durationMs }))
            InfoLine(tr("Clips", "المقاطع"), if (clipCount == 0) tr("none", "لا يوجد") else clipCount.toString())
        }
        Box(Modifier.fillMaxWidth().height(0.5.dp).background(h.separator))
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(tr("Created: ", "أُنشئ: ") + df.format(Date(p.created)), color = h.secondary, fontSize = 15.sp)
                Text(tr("Updated: ", "عُدّل: ") + df.format(Date(p.updated)), color = h.secondary, fontSize = 15.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BigButton(tr("Open", "فتح"), Modifier.weight(1f).height(48.dp)) { onOpen() }
                Box(
                    Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(h.fill).tap { menu = true },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.MoreVert, contentDescription = null, tint = h.label)
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text(tr("Duplicate", "نسخ")) }, onClick = { menu = false; onDuplicate() })
                        DropdownMenuItem(text = { Text(tr("Delete", "حذف"), color = h.red) }, onClick = { menu = false; onDelete() })
                    }
                }
            }
        }
    }
}

@Composable
fun InfoLine(label: String, value: String) {
    val h = LocalHig.current
    Row {
        Text("$label: ", color = h.secondary, fontSize = 17.sp)
        Text(value, color = h.label, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

// ======================= المحرر | Editor =======================

@Composable
fun EditorScreen(vm: MainVM, p: Project, ex: ExportUi) {
    val h = LocalHig.current
    val ctx = LocalContext.current
    val s = p.settings
    fun upd(f: (Settings) -> Settings) = vm.update(p.copy(settings = f(s)))
    fun setClip(i: Int, c: ClipSpec) = vm.update(p.copy(clips = p.clips.toMutableList().also { it[i] = c }))

    var selSrc by remember(p.id) { mutableIntStateOf(0) }
    var linkText by remember(p.id) { mutableStateOf("") }
    val sel = selSrc.coerceIn(0, (p.sources.size - 1).coerceAtLeast(0))

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) vm.addLocal(p.id, uri)
    }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { vm.requestExport(p) }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().height(48.dp).padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("‹ " + tr("Projects", "المشاريع"), color = h.blue, fontSize = 17.sp, modifier = Modifier.tap { vm.openId = null }.padding(8.dp))
            Spacer(Modifier.weight(1f))
            if (ex.running || ex.finished)
                Text(tr("Export", "التصدير") + (if (ex.running) " " + (ex.progress * 100).toInt() + "%" else ""), color = h.blue, fontSize = 15.sp,
                    modifier = Modifier.tap { vm.showExport = true }.padding(8.dp))
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            Text(p.name.ifEmpty { tr("Project", "مشروع") }, color = h.label, fontSize = 34.sp, fontWeight = FontWeight.Bold, maxLines = 1)

            Group(tr("Project", "المشروع")) {
                Cell {
                    Text(tr("Name", "الاسم"), color = h.label, fontSize = 17.sp, modifier = Modifier.width(90.dp))
                    Field(p.name, tr("Project name", "اسم المشروع"), Modifier.weight(1f)) { vm.update(p.copy(name = it)) }
                }
            }

            // ---------- المصادر ----------
            Group(
                tr("Sources", "المصادر"),
                tr("Paste one or many YouTube links (or share a video from the YouTube app to this app). Only the clip ranges you set are downloaded.",
                    "الصق رابطًا أو عدة روابط YouTube (أو شارك فيديو من تطبيق YouTube إلى هذا التطبيق). يُنزَّل فقط نطاق المقاطع الذي تحدده.")
            ) {
                p.sources.forEachIndexed { i, sr ->
                    if (i > 0) Sep()
                    Row(
                        Modifier.fillMaxWidth().tap { selSrc = i }.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Thumb(sr, Modifier.size(width = 72.dp, height = 44.dp).clip(RoundedCornerShape(6.dp)))
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(sr.name.ifEmpty { sr.uri }, color = h.label, fontSize = 15.sp, maxLines = 2)
                            Text(
                                (if (sr.isYoutube) "YouTube" else tr("Phone", "الهاتف")) + (if (sr.durationMs > 0) " · " + fmtTime(sr.durationMs) else ""),
                                color = h.secondary, fontSize = 13.sp
                            )
                        }
                        if (i == sel) Text("●", color = h.blue, fontSize = 12.sp)
                        Text("✕", color = h.secondary, fontSize = 16.sp, modifier = Modifier.tap { vm.removeSource(p.id, i) }.padding(10.dp))
                    }
                }
                if (p.sources.isNotEmpty()) Sep()
                Cell {
                    Field(linkText, tr("Paste YouTube link(s)…", "الصق رابط أو عدة روابط…"), Modifier.weight(1f), singleLine = false) { linkText = it }
                    Text(tr("Add", "إضافة"), color = h.blue, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.tap { if (linkText.isNotBlank()) { vm.addLinks(p.id, linkText); linkText = "" } }.padding(8.dp))
                }
                Sep()
                Cell(Modifier.tap { picker.launch(arrayOf("video/*")) }) {
                    Text("＋ " + tr("Add video from phone", "إضافة فيديو من الهاتف"), color = h.blue, fontSize = 17.sp)
                }
            }

            // ---------- المعاينة ----------
            if (p.sources.isNotEmpty()) {
                val cur = p.sources[sel]
                Group(tr("Preview & trim", "المعاينة والقص"), tr("Play, mark start/end, then tap ＋ Clip. Flip settings are shown live.", "شغّل، حدّد البداية والنهاية، ثم اضغط ＋ مقطع. يظهر القلب مباشرة.")) {
                    key(cur.uri) {
                        SourcePreview(cur, s.flipH, s.flipV) { a, b ->
                            val nc = ClipSpec(sel, fmtPrecise(a), fmtPrecise(b))
                            val ci = p.clips.indexOfFirst { it.start.isBlank() && it.end.isBlank() }
                            vm.update(p.copy(clips = if (ci >= 0) p.clips.toMutableList().also { it[ci] = nc } else p.clips + nc))
                        }
                    }
                }
            }

            // ---------- المقاطع ----------
            Group(
                tr("Clips", "المقاطع"),
                tr("Format MM:SS or HH:MM:SS (decimals allowed: 01:23.5). Empty rows are skipped. Each clip is exported as its own file.",
                    "الصيغة MM:SS أو HH:MM:SS (يُقبل كسر مثل 01:23.5). تُتخطى الأسطر الفارغة. كل مقطع يُصدَّر في ملف مستقل.")
            ) {
                p.clips.forEachIndexed { i, c ->
                    if (i > 0) Sep()
                    Cell {
                        if (p.sources.size > 1)
                            Text("S${c.src + 1}", color = h.blue, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.tap { setClip(i, c.copy(src = (c.src + 1) % p.sources.size)) }.padding(end = 10.dp, top = 8.dp, bottom = 8.dp))
                        else
                            Text("${i + 1}", color = h.secondary, fontSize = 17.sp, modifier = Modifier.width(24.dp))
                        Field(c.start, "00:00", Modifier.weight(1f)) { v -> setClip(i, c.copy(start = v)) }
                        Text("→", color = h.secondary, fontSize = 17.sp, modifier = Modifier.padding(horizontal = 8.dp))
                        Field(c.end, "00:30", Modifier.weight(1f)) { v -> setClip(i, c.copy(end = v)) }
                        Text("✕", color = h.secondary, fontSize = 16.sp,
                            modifier = Modifier.tap { vm.update(p.copy(clips = p.clips.filterIndexed { j, _ -> j != i }.ifEmpty { listOf(ClipSpec()) })) }.padding(start = 6.dp, top = 8.dp, bottom = 8.dp))
                    }
                }
                Sep()
                Cell(Modifier.tap { if (p.clips.size < 20) vm.update(p.copy(clips = p.clips + ClipSpec(src = sel))) }) {
                    Text("＋ " + tr("Add clip", "إضافة مقطع"), color = h.blue, fontSize = 17.sp)
                }
            }

            Group(tr("Format", "الاتجاه")) {
                SegmentedCell(
                    listOf(tr("Portrait 9:16", "طولي 9:16"), tr("Landscape 16:9", "عرضي 16:9"), tr("Original", "الأصل")),
                    s.orientation
                ) { v -> upd { it.copy(orientation = v) } }
            }

            if (s.orientation != 2) {
                Group(
                    tr("Framing", "التأطير"),
                    if (s.framing == 0) tr("Face detection runs on-device. It can pick the wrong person in crowded shots — use Left/Right or Manual then.",
                        "كشف الوجه يعمل على الجهاز. قد يختار شخصًا خطأ عند التزاحم — استخدم الأيسر/الأيمن أو اليدوي حينها.") else null
                ) {
                    SegmentedCell(
                        listOf(tr("Auto track", "تتبع تلقائي"), tr("Center", "منتصف"), tr("Manual", "يدوي")),
                        s.framing
                    ) { v -> upd { it.copy(framing = v) } }
                    if (s.framing == 0) {
                        Sep()
                        SegmentedCell(listOf(tr("Any person", "أي شخص"), tr("Left", "الأيسر"), tr("Right", "الأيمن")), s.subject) { v -> upd { it.copy(subject = v) } }
                        Sep()
                        SegmentedCell(listOf(tr("Wide", "واسع"), tr("Medium", "متوسط"), tr("Close", "قريب")), s.faceSize) { v -> upd { it.copy(faceSize = v) } }
                    }
                    if (s.framing == 2) {
                        Sep()
                        SliderCell(tr("Horizontal", "أفقي"), "${s.manualX.toInt()}%", s.manualX, 0f..100f) { v -> upd { it.copy(manualX = v) } }
                        Sep()
                        SliderCell(tr("Vertical", "عمودي"), "${s.manualY.toInt()}%", s.manualY, 0f..100f) { v -> upd { it.copy(manualY = v) } }
                        Sep()
                        SliderCell(tr("Zoom", "التكبير"), "×" + String.format("%.1f", s.manualZoom), s.manualZoom, 1f..3f) { v -> upd { it.copy(manualZoom = v) } }
                    }
                }
            }

            Group(tr("Flip", "القلب"), tr("Mirrors the exported video (text will appear reversed).", "يعكس الفيديو المُصدَّر (سيظهر النص معكوسًا).")) {
                Cell {
                    Text(tr("Mirror horizontally", "قلب أفقي (مرآة)"), color = h.label, fontSize = 17.sp)
                    Spacer(Modifier.weight(1f))
                    IosSwitch(s.flipH) { v -> upd { it.copy(flipH = v) } }
                }
                Sep()
                Cell {
                    Text(tr("Flip vertically", "قلب رأسي"), color = h.label, fontSize = 17.sp)
                    Spacer(Modifier.weight(1f))
                    IosSwitch(s.flipV) { v -> upd { it.copy(flipV = v) } }
                }
            }

            val qNames = listOf(tr("Best (source detail)", "الأفضل (تفاصيل المصدر)"), "2160p", "1440p", "1080p", "720p", "480p")
            var qMenu by remember { mutableStateOf(false) }
            Group(
                tr("Quality", "الجودة"),
                tr("The number is the shorter side. Higher than the source detail means upscaling.", "الرقم = الضلع الأقصر. أعلى من تفاصيل المصدر يعني تكبيرًا.")
            ) {
                Cell(Modifier.tap { qMenu = true }) {
                    Text(tr("Resolution", "الدقة"), color = h.label, fontSize = 17.sp)
                    Spacer(Modifier.weight(1f))
                    Box {
                        Text(qNames[s.quality] + "  ›", color = h.secondary, fontSize = 17.sp)
                        DropdownMenu(expanded = qMenu, onDismissRequest = { qMenu = false }) {
                            qNames.forEachIndexed { i, n ->
                                DropdownMenuItem(text = { Text(n) }, onClick = { qMenu = false; upd { it.copy(quality = i) } })
                            }
                        }
                    }
                }
                if (p.sources.any { it.isYoutube }) {
                    Sep()
                    Cell {
                        Column(Modifier.weight(1f)) {
                            Text(tr("Data saver", "توفير البيانات"), color = h.label, fontSize = 17.sp)
                            Text(tr("YouTube download capped at 720p + smallest audio. Size is shown before any download.",
                                "تنزيل YouTube بحد أقصى 720p وأصغر صوت. يظهر الحجم المتوقع قبل أي تنزيل."), color = h.secondary, fontSize = 13.sp)
                        }
                        IosSwitch(s.dataSaver) { v -> upd { it.copy(dataSaver = v) } }
                    }
                }
            }

            Group(tr("Fade", "التلاشي")) {
                SegmentedCell(
                    listOf(tr("None", "بدون"), tr("In & Out", "دخول وخروج"), tr("In", "دخول"), tr("Out", "خروج")),
                    s.fadeMode
                ) { v -> upd { it.copy(fadeMode = v) } }
                if (s.fadeMode != 0) {
                    Sep()
                    SliderCell(tr("Duration", "المدة"), String.format("%.1f s", s.fadeSec), s.fadeSec, 0.2f..2f) { v -> upd { it.copy(fadeSec = v) } }
                    Sep()
                    Cell {
                        Text(tr("Fade audio", "تلاشي الصوت"), color = h.label, fontSize = 17.sp)
                        Spacer(Modifier.weight(1f))
                        IosSwitch(s.fadeAudio) { v -> upd { it.copy(fadeAudio = v) } }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
        Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
            BigButton(
                if (ex.running) tr("Add to export queue", "أضف إلى طابور التصدير") else tr("Export", "تصدير"),
                Modifier.fillMaxWidth(), enabled = p.sources.isNotEmpty()
            ) {
                if (Build.VERSION.SDK_INT >= 33 &&
                    ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
                else vm.requestExport(p)
            }
        }
    }
}

// ======================= شاشة التصدير | Export sheet =======================

@Composable
fun ExportSheet(vm: MainVM, ex: ExportUi) {
    val h = LocalHig.current
    val ctx = LocalContext.current
    Box(Modifier.fillMaxSize().background(Color(0x99000000)).tap { vm.showExport = false }, contentAlignment = Alignment.BottomCenter) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)).background(h.card)
                .tap { }.navigationBarsPadding().padding(20.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(if (ex.running) tr("Exporting…", "جارٍ التصدير…") else tr("Done", "اكتمل"), color = h.label, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            if (ex.running) {
                Text(ex.current + (if (ex.stage.isNotEmpty()) " — " + ex.stage else ""), color = h.secondary, fontSize = 15.sp)
                LinearProgressIndicator(progress = { ex.progress.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth(), color = h.blue, trackColor = h.fill)
                Text(tr("Runs in the background — you can leave the app. Progress is in the notification.",
                    "يعمل في الخلفية — يمكنك مغادرة التطبيق. التقدّم في الإشعار."), color = h.secondary, fontSize = 13.sp)
                if (ex.queued.isNotEmpty())
                    Text(tr("Queue: ", "الطابور: ") + ex.queued.joinToString("، "), color = h.secondary, fontSize = 13.sp)
            }
            ex.results.forEach { (name, uri) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("✓ $name", color = h.label, fontSize = 15.sp, maxLines = 1, modifier = Modifier.weight(1f))
                    TextButton(onClick = {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "video/mp4"
                            putExtra(Intent.EXTRA_STREAM, Uri.parse(uri))
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        ctx.startActivity(Intent.createChooser(send, null))
                    }) { Text(tr("Share", "مشاركة"), color = h.blue) }
                }
            }
            if (!ex.running && ex.results.isNotEmpty())
                Text(tr("Saved in Movies ▸ Smart Recitation Studio.", "حُفظت في Movies ▸ Smart Recitation Studio."), color = h.secondary, fontSize = 13.sp)
            ex.errors.forEach { Text("✕ $it", color = h.red, fontSize = 14.sp) }
            ex.warnings.forEach { Text("⚠ $it", color = h.secondary, fontSize = 13.sp) }
            if (ex.running) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    BigButton(tr("Hide", "إخفاء"), Modifier.weight(1f), filled = false) { vm.showExport = false }
                    BigButton(tr("Cancel all", "إلغاء الكل"), Modifier.weight(1f)) { ExportEngine.cancelAll() }
                }
            } else {
                BigButton(tr("Done", "تم"), Modifier.fillMaxWidth()) { ExportEngine.clearDone(); vm.showExport = false }
            }
        }
    }
}
