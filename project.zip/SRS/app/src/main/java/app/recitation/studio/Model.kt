package app.recitation.studio

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale
import java.util.UUID

/** خطأ مفهوم للمستخدم | user-facing error */
class UserError(message: String) : Exception(message)

fun tr(en: String, ar: String): String =
    if (Locale.getDefault().language == "ar") ar else en

data class Source(
    val uri: String,
    val name: String = "",
    val durationMs: Long = 0,
    val thumb: String = ""
) {
    val isYoutube: Boolean get() = uri.startsWith("http")
}

data class ClipSpec(val src: Int = 0, val start: String = "", val end: String = "")

data class Settings(
    val orientation: Int = 0,      // 0 portrait 9:16 | 1 landscape 16:9 | 2 original
    val framing: Int = 0,          // 0 auto track | 1 center | 2 manual
    val subject: Int = 0,          // 0 auto | 1 left | 2 right
    val faceSize: Int = 1,         // 0 wide | 1 medium | 2 close
    val manualX: Float = 50f,
    val manualY: Float = 45f,
    val manualZoom: Float = 1f,
    val quality: Int = 3,          // 0 best | 1 2160 | 2 1440 | 3 1080 | 4 720 | 5 480
    val fadeMode: Int = 1,         // 0 none | 1 in+out | 2 in | 3 out
    val fadeSec: Float = 0.6f,
    val fadeAudio: Boolean = true,
    val flipH: Boolean = false,
    val flipV: Boolean = false,
    val dataSaver: Boolean = false
)

data class Project(
    val id: String,
    val name: String,
    val sources: List<Source> = emptyList(),
    val clips: List<ClipSpec> = listOf(ClipSpec()),
    val settings: Settings = Settings(),
    val created: Long,
    val updated: Long,
    val outputs: List<String> = emptyList()
)

/** 0 = Not Set, 1 = Ready, 2 = Exported */
fun Project.status(): Int = when {
    sources.isEmpty() -> 0
    outputs.isNotEmpty() -> 2
    else -> 1
}

fun newId(): String = UUID.randomUUID().toString()

fun fmtTime(ms: Long): String {
    val s = ms / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
    else String.format(Locale.US, "%02d:%02d", m, sec)
}

fun fmtPrecise(ms: Long): String {
    val t = ms / 100
    val tenth = (t % 10).toInt()
    val sec = (t / 10) % 60
    val min = (t / 600) % 60
    val h = t / 36000
    val base = if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, min, sec) else String.format(Locale.US, "%02d:%02d", min, sec)
    return if (tenth == 0) base else "$base.$tenth"
}

// ---------- الوقت | time parsing ----------
fun parseTime(raw: String, label: String): Double {
    val s = buildString {
        for (ch in raw.trim()) {
            append(
                when (ch) {
                    in '\u0660'..'\u0669' -> '0' + (ch - '\u0660')
                    in '\u06F0'..'\u06F9' -> '0' + (ch - '\u06F0')
                    '\u060C', ',' -> '.'
                    else -> ch
                }
            )
        }
    }
    if (s.isEmpty()) throw UserError("$label: " + tr("field is empty.", "الحقل فارغ."))
    val parts = s.split(":")
    val num = Regex("""\d+(\.\d+)?""")
    if (parts.size > 3 || !parts.all { num.matches(it) })
        throw UserError("$label: " + tr("invalid format “$raw”. Use MM:SS or HH:MM:SS.", "الصيغة «$raw» غير صحيحة. استخدم MM:SS أو HH:MM:SS."))
    if (parts.dropLast(1).any { '.' in it })
        throw UserError("$label: " + tr("decimals are allowed in seconds only.", "الكسر العشري مسموح في خانة الثواني فقط."))
    val v = parts.map { it.toDouble() }
    if (v.size > 1 && v.drop(1).any { it >= 60 })
        throw UserError("$label: " + tr("minutes and seconds must be below 60.", "الدقائق والثواني يجب أن تكون أقل من 60."))
    return v.fold(0.0) { acc, x -> acc * 60 + x }
}

class ParsedClip(val src: Int, val startMs: Long, val endMs: Long)

/** يعيد المقاطع غير الفارغة بعد التحقق */
fun parseClips(p: Project): List<ParsedClip> {
    if (p.sources.isEmpty()) throw UserError(tr("Add a video or YouTube link first.", "أضف فيديو أو رابط YouTube أولًا."))
    val out = mutableListOf<ParsedClip>()
    p.clips.forEachIndexed { i, c ->
        val s = c.start.trim()
        val e = c.end.trim()
        val n = i + 1
        if (s.isEmpty() && e.isEmpty()) return@forEachIndexed
        if (s.isEmpty() || e.isEmpty())
            throw UserError(tr("Clip $n: enter both start and end.", "المقطع $n: يجب إدخال البداية والنهاية معًا."))
        if (c.src !in p.sources.indices)
            throw UserError(tr("Clip $n: its source was removed.", "المقطع $n: مصدره محذوف."))
        val a = parseTime(s, tr("Clip $n start", "المقطع $n - البداية"))
        val b = parseTime(e, tr("Clip $n end", "المقطع $n - النهاية"))
        if (b - a < 0.5)
            throw UserError(tr("Clip $n: end must be at least 0.5s after start.", "المقطع $n: النهاية يجب أن تكون بعد البداية بنصف ثانية على الأقل."))
        val d = p.sources[c.src].durationMs
        if (d > 0 && b * 1000 > d + 500)
            throw UserError(tr("Clip $n: end ($e) is beyond the video length (${fmtTime(d)}).", "المقطع $n: النهاية ($e) تتجاوز مدة الفيديو (${fmtTime(d)})."))
        out += ParsedClip(c.src, (a * 1000).toLong(), (b * 1000).toLong())
    }
    if (out.isEmpty()) throw UserError(tr("Enter at least one clip (start and end).", "أدخل مقطعًا واحدًا على الأقل (البداية والنهاية)."))
    return out
}

// ---------- JSON ----------
private fun Settings.toJson() = JSONObject()
    .put("o", orientation).put("f", framing).put("s", subject).put("fs", faceSize)
    .put("mx", manualX.toDouble()).put("my", manualY.toDouble()).put("mz", manualZoom.toDouble())
    .put("q", quality).put("fm", fadeMode).put("fd", fadeSec.toDouble()).put("fa", fadeAudio)
    .put("fh", flipH).put("fv", flipV).put("ds", dataSaver)

private fun JSONObject.toSettings() = Settings(
    optInt("o", 0), optInt("f", 0), optInt("s", 0), optInt("fs", 1),
    optDouble("mx", 50.0).toFloat(), optDouble("my", 45.0).toFloat(), optDouble("mz", 1.0).toFloat(),
    optInt("q", 3), optInt("fm", 1), optDouble("fd", 0.6).toFloat(), optBoolean("fa", true),
    optBoolean("fh", false), optBoolean("fv", false), optBoolean("ds", false)
)

private fun Project.toJson(): JSONObject {
    val clipsArr = JSONArray()
    clips.forEach { clipsArr.put(JSONObject().put("sr", it.src).put("s", it.start).put("e", it.end)) }
    val srcArr = JSONArray()
    sources.forEach { srcArr.put(JSONObject().put("u", it.uri).put("n", it.name).put("d", it.durationMs).put("t", it.thumb)) }
    val outs = JSONArray()
    outputs.forEach { outs.put(it) }
    return JSONObject().put("id", id).put("name", name).put("srcs", srcArr)
        .put("clips", clipsArr).put("set", settings.toJson())
        .put("c", created).put("u", updated).put("out", outs)
}

private fun JSONObject.toProject(): Project {
    val sources = mutableListOf<Source>()
    val sa = optJSONArray("srcs")
    if (sa != null) {
        for (i in 0 until sa.length()) {
            val o = sa.getJSONObject(i)
            sources += Source(o.optString("u"), o.optString("n"), o.optLong("d"), o.optString("t"))
        }
    } else if (optString("uri").isNotEmpty()) {          // مشاريع النسخة القديمة
        sources += Source(optString("uri"), optString("src"), optLong("dur"))
    }
    val ca = optJSONArray("clips") ?: JSONArray()
    val clips = mutableListOf<ClipSpec>()
    for (i in 0 until ca.length()) {
        val o = ca.getJSONObject(i)
        clips += ClipSpec(o.optInt("sr", 0), o.optString("s"), o.optString("e"))
    }
    if (clips.isEmpty()) clips += ClipSpec()
    val oa = optJSONArray("out") ?: JSONArray()
    return Project(
        id = optString("id", newId()), name = optString("name", "Project"),
        sources = sources, clips = clips, settings = (optJSONObject("set") ?: JSONObject()).toSettings(),
        created = optLong("c"), updated = optLong("u"),
        outputs = (0 until oa.length()).map { oa.getString(it) }
    )
}

class Store(context: Context) {
    private val file = File(context.filesDir, "projects.json")

    fun load(): List<Project> = try {
        val arr = JSONArray(file.readText())
        (0 until arr.length()).map { arr.getJSONObject(it).toProject() }
    } catch (e: Exception) {
        emptyList()
    }

    fun save(list: List<Project>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        file.writeText(arr.toString())
    }
}

/** مستودع مشترك بين الواجهة وخدمة التصدير في الخلفية */
object Repo {
    private var store: Store? = null
    val projects = MutableStateFlow<List<Project>>(emptyList())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var saveJob: Job? = null

    @Synchronized
    fun init(ctx: Context) {
        if (store != null) return
        val st = Store(ctx.applicationContext)
        store = st
        projects.value = st.load()
    }

    fun add(p: Project) { projects.update { it + p }; persist() }
    fun remove(id: String) { projects.update { l -> l.filter { it.id != id } }; persist() }
    fun get(id: String): Project? = projects.value.firstOrNull { it.id == id }

    fun mutate(id: String, f: (Project) -> Project) {
        val now = System.currentTimeMillis()
        projects.update { l -> l.map { if (it.id == id) f(it).copy(updated = now) else it } }
        persist()
    }

    private fun persist() {
        saveJob?.cancel()
        val snap = projects.value
        saveJob = scope.launch { delay(300); store?.save(snap) }
    }
}
