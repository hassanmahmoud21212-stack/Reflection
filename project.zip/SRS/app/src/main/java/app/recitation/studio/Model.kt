package app.recitation.studio

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

/** خطأ مفهوم للمستخدم | user-facing error */
class UserError(message: String) : Exception(message)

fun tr(en: String, ar: String): String =
    if (Locale.getDefault().language == "ar") ar else en

data class ClipSpec(val start: String = "", val end: String = "")

data class Settings(
    val orientation: Int = 0,      // 0 portrait 9:16 | 1 landscape 16:9 | 2 original
    val framing: Int = 0,          // 0 auto track | 1 center | 2 manual
    val subject: Int = 0,          // 0 auto | 1 left | 2 right
    val faceSize: Int = 1,         // 0 wide | 1 medium | 2 close
    val manualX: Float = 50f,
    val manualY: Float = 45f,
    val manualZoom: Float = 1f,
    val quality: Int = 3,          // 0 best | 1 2160 | 2 1440 | 3 1080 | 4 720 | 5 480
    val fadeMode: Int = 1,         // 0 none | 1 in+out | 2 in | 3 out
    val fadeSec: Float = 0.6f,
    val fadeAudio: Boolean = true
)

data class Project(
    val id: String,
    val name: String,
    val sourceUri: String = "",
    val sourceName: String = "",
    val durationMs: Long = 0,
    val clips: List<ClipSpec> = List(5) { ClipSpec() },
    val settings: Settings = Settings(),
    val created: Long,
    val updated: Long,
    val outputs: List<String> = emptyList()
)

/** 0 = Not Set, 1 = Ready, 2 = Exported */
fun Project.status(): Int = when {
    sourceUri.isEmpty() -> 0
    outputs.isNotEmpty() -> 2
    else -> 1
}

fun newId(): String = UUID.randomUUID().toString()

fun fmtTime(ms: Long): String {
    val s = ms / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
    else String.format(Locale.US, "%02d:%02d", m, sec)
}

// ---------- الوقت | time parsing ----------
fun parseTime(raw: String, label: String): Double {
    val s = buildString {
        for (ch in raw.trim()) {
            append(
                when (ch) {
                    in '\u0660'..'\u0669' -> '0' + (ch - '\u0660')
                    in '\u06F0'..'\u06F9' -> '0' + (ch - '\u06F0')
                    '\u060C', ',' -> '.'
                    else -> ch
                }
            )
        }
    }
    if (s.isEmpty()) throw UserError("$label: " + tr("field is empty.", "الحقل فارغ."))
    val parts = s.split(":")
    val num = Regex("""\d+(\.\d+)?""")
    if (parts.size > 3 || !parts.all { num.matches(it) })
        throw UserError("$label: " + tr("invalid format “$raw”. Use MM:SS or HH:MM:SS.", "الصيغة «$raw» غير صحيحة. استخدم MM:SS أو HH:MM:SS."))
    if (parts.dropLast(1).any { '.' in it })
        throw UserError("$label: " + tr("decimals are allowed in seconds only.", "الكسر العشري مسموح في خانة الثواني فقط."))
    val v = parts.map { it.toDouble() }
    if (v.size > 1 && v.drop(1).any { it >= 60 })
        throw UserError("$label: " + tr("minutes and seconds must be below 60.", "الدقائق والثواني يجب أن تكون أقل من 60."))
    return v.fold(0.0) { acc, x -> acc * 60 + x }
}

/** يعيد (بداية، نهاية) بالميلي ثانية لكل مقطع غير فارغ */
fun parseClips(p: Project): List<Pair<Long, Long>> {
    val out = mutableListOf<Pair<Long, Long>>()
    p.clips.forEachIndexed { i, c ->
        val s = c.start.trim()
        val e = c.end.trim()
        val n = i + 1
        if (s.isEmpty() && e.isEmpty()) {
            if (i == 0) throw UserError(tr("Clip 1 is required: enter start and end.", "المقطع 1 مطلوب: أدخل البداية والنهاية."))
            return@forEachIndexed
        }
        if (s.isEmpty() || e.isEmpty())
            throw UserError(tr("Clip $n: enter both start and end.", "المقطع $n: يجب إدخال البداية والنهاية معًا."))
        val a = parseTime(s, tr("Clip $n start", "المقطع $n - البداية"))
        val b = parseTime(e, tr("Clip $n end", "المقطع $n - النهاية"))
        if (b - a < 0.5)
            throw UserError(tr("Clip $n: end must be at least 0.5s after start.", "المقطع $n: النهاية يجب أن تكون بعد البداية بنصف ثانية على الأقل."))
        if (p.durationMs > 0 && b * 1000 > p.durationMs + 500)
            throw UserError(tr("Clip $n: end ($e) is beyond the video length (${fmtTime(p.durationMs)}).", "المقطع $n: النهاية ($e) تتجاوز مدة الفيديو (${fmtTime(p.durationMs)})."))
        out += (a * 1000).toLong() to (b * 1000).toLong()
    }
    return out
}

// ---------- JSON ----------
private fun Settings.toJson() = JSONObject()
    .put("o", orientation).put("f", framing).put("s", subject).put("fs", faceSize)
    .put("mx", manualX.toDouble()).put("my", manualY.toDouble()).put("mz", manualZoom.toDouble())
    .put("q", quality).put("fm", fadeMode).put("fd", fadeSec.toDouble()).put("fa", fadeAudio)

private fun JSONObject.toSettings() = Settings(
    optInt("o", 0), optInt("f", 0), optInt("s", 0), optInt("fs", 1),
    optDouble("mx", 50.0).toFloat(), optDouble("my", 45.0).toFloat(), optDouble("mz", 1.0).toFloat(),
    optInt("q", 3), optInt("fm", 1), optDouble("fd", 0.6).toFloat(), optBoolean("fa", true)
)

private fun Project.toJson(): JSONObject {
    val clipsArr = JSONArray()
    clips.forEach { clipsArr.put(JSONObject().put("s", it.start).put("e", it.end)) }
    val outs = JSONArray()
    outputs.forEach { outs.put(it) }
    return JSONObject().put("id", id).put("name", name).put("uri", sourceUri).put("src", sourceName)
        .put("dur", durationMs).put("clips", clipsArr).put("set", settings.toJson())
        .put("c", created).put("u", updated).put("out", outs)
}

private fun JSONObject.toProject(): Project {
    val ca = optJSONArray("clips") ?: JSONArray()
    val clips = MutableList(5) { ClipSpec() }
    for (i in 0 until minOf(5, ca.length())) {
        val o = ca.getJSONObject(i)
        clips[i] = ClipSpec(o.optString("s"), o.optString("e"))
    }
    val oa = optJSONArray("out") ?: JSONArray()
    return Project(
        id = optString("id", newId()), name = optString("name", "Project"),
        sourceUri = optString("uri"), sourceName = optString("src"), durationMs = optLong("dur"),
        clips = clips, settings = (optJSONObject("set") ?: JSONObject()).toSettings(),
        created = optLong("c"), updated = optLong("u"),
        outputs = (0 until oa.length()).map { oa.getString(it) }
    )
}

class Store(context: Context) {
    private val file = File(context.filesDir, "projects.json")

    fun load(): List<Project> = try {
        val arr = JSONArray(file.readText())
        (0 until arr.length()).map { arr.getJSONObject(it).toProject() }
    } catch (e: Exception) {
        emptyList()
    }

    fun save(list: List<Project>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        file.writeText(arr.toString())
    }
}
