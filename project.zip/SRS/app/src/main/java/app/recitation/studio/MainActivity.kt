package app.recitation.studio

import android.app.Application
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class ExportUi(
    val visible: Boolean = false,
    val running: Boolean = false,
    val stage: String = "",
    val progress: Float = 0f,
    val results: List<Pair<String, String>> = emptyList(),   // (اسم الملف، Uri)
    val warnings: List<String> = emptyList(),
    val error: String? = null
)

class MainVM(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)
    val projects = MutableStateFlow(store.load())
    var openId by mutableStateOf<String?>(null)
    val exportUi = MutableStateFlow(ExportUi())
    private var job: Job? = null
    private var saveJob: Job? = null

    private fun persist() {
        saveJob?.cancel()
        val snap = projects.value
        saveJob = viewModelScope.launch(Dispatchers.IO) { delay(300); store.save(snap) }
    }

    private fun mutate(id: String, f: (Project) -> Project) {
        val now = System.currentTimeMillis()
        projects.value = projects.value.map { if (it.id == id) f(it).copy(updated = now) else it }
        persist()
    }

    fun update(p: Project) = mutate(p.id) { p }

    fun newProject(): Project {
        val now = System.currentTimeMillis()
        val p = Project(newId(), "Project ${projects.value.size + 1}", created = now, updated = now)
        projects.value = projects.value + p
        persist()
        openId = p.id
        return p
    }

    fun createFromVideo(uri: Uri) {
        val p = newProject()
        setSource(p.id, uri)
    }

    fun duplicate(p: Project) {
        val now = System.currentTimeMillis()
        projects.value = projects.value + p.copy(id = newId(), name = p.name + " 2", created = now, updated = now, outputs = emptyList())
        persist()
    }

    fun delete(id: String) {
        projects.value = projects.value.filter { it.id != id }
        if (openId == id) openId = null
        persist()
    }

    fun setSource(id: String, uri: Uri) {
        val ctx = getApplication<Application>()
        try {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }
        viewModelScope.launch {
            val (name, dur) = withContext(Dispatchers.IO) {
                var n = "video"
                try {
                    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (i >= 0 && c.moveToFirst()) n = c.getString(i)
                    }
                } catch (_: Exception) {
                }
                var d = 0L
                val m = MediaMetadataRetriever()
                try {
                    m.setDataSource(ctx, uri)
                    d = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                } catch (_: Exception) {
                } finally {
                    m.release()
                }
                n to d
            }
            mutate(id) { it.copy(sourceUri = uri.toString(), sourceName = name, durationMs = dur) }
        }
    }

    fun closeExport() {
        job?.cancel()
        exportUi.value = ExportUi()
    }

    fun startExport(p: Project) {
        job?.cancel()
        job = viewModelScope.launch {
            val ctx = getApplication<Application>()
            val warnings = mutableListOf<String>()
            val results = mutableListOf<Pair<String, String>>()
            exportUi.value = ExportUi(visible = true, running = true, stage = tr("Preparing…", "جارٍ التجهيز…"))
            try {
                if (p.sourceUri.isEmpty()) throw UserError(tr("Choose a video first.", "اختر فيديو أولًا."))
                val uri = Uri.parse(p.sourceUri)
                val clips = parseClips(p)
                val s = p.settings
                val safe = p.name.replace(Regex("""[\\/:*?"<>|]"""), "_").trim().ifEmpty { "Project" }
                val tag = when (s.orientation) { 0 -> "portrait"; 1 -> "landscape"; else -> "original" }

                for ((k, c) in clips.withIndex()) {
                    val base = k.toFloat() / clips.size
                    val span = 1f / clips.size
                    val n = k + 1
                    var track: TrackResult? = null
                    if (s.orientation != 2 && s.framing == 0) {
                        exportUi.value = exportUi.value.copy(stage = tr("Clip $n/${clips.size}: tracking face…", "المقطع $n/${clips.size}: تتبع الوجه…"))
                        track = withContext(Dispatchers.Default) {
                            Tracker.analyze(ctx, uri, c.first, c.second, s.subject) { f ->
                                exportUi.value = exportUi.value.copy(progress = base + span * 0.35f * f)
                            }
                        }
                        val cov = track.detected * 100 / track.samples.coerceAtLeast(1)
                        if (track.detected == 0)
                            warnings += tr("Clip $n: no face found — centered crop used.", "المقطع $n: لم يُعثر على وجه — استُخدم قص من المنتصف.")
                        else if (cov < 50)
                            warnings += tr("Clip $n: face found in only $cov% of samples — check the result.", "المقطع $n: الوجه ظهر في $cov% فقط من العيّنات — راجع النتيجة.")
                    }
                    exportUi.value = exportUi.value.copy(stage = tr("Clip $n/${clips.size}: encoding…", "المقطع $n/${clips.size}: ترميز…"))
                    val out = Exporter.export(ctx, uri, s, c.first, c.second, track) { f ->
                        exportUi.value = exportUi.value.copy(progress = base + span * (0.35f + 0.65f * f))
                    }
                    if (out.plan.upscaled)
                        warnings += tr("Clip $n: output is larger than the source detail (upscaled).", "المقطع $n: الدقة المختارة أكبر من تفاصيل المصدر (تكبير).")
                    val name = "${safe}_clip${n}_$tag.mp4"
                    val u = withContext(Dispatchers.IO) { Exporter.publish(ctx, out.file, name, safe) }
                    results += name to u.toString()
                    exportUi.value = exportUi.value.copy(progress = base + span)
                }
                mutate(p.id) { it.copy(outputs = it.outputs + results.map { r -> r.second }) }
                exportUi.value = ExportUi(visible = true, running = false, progress = 1f, results = results, warnings = warnings,
                    stage = tr("Done", "اكتمل"))
            } catch (e: CancellationException) {
                throw e
            } catch (e: UserError) {
                exportUi.value = ExportUi(visible = true, error = e.message, warnings = warnings, results = results)
            } catch (e: Throwable) {
                exportUi.value = ExportUi(visible = true, warnings = warnings, results = results,
                    error = tr("Export failed: ", "فشل التصدير: ") + (e.message ?: e.javaClass.simpleName))
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    private val vm: MainVM by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { HigTheme { App(vm) } }
    }
}
