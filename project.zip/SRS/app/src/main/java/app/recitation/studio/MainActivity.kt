package app.recitation.studio

import android.app.Application
import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class ConfirmUi(val project: Project, val bytes: Long, val height: Int, val parts: Int, val cellular: Boolean)

fun fmtBytes(b: Long): String = when {
    b <= 0L -> tr("unknown size", "حجم غير معروف")
    b >= 1_000_000_000L -> String.format(Locale.US, "%.1f GB", b / 1e9)
    b >= 1_000_000L -> String.format(Locale.US, "%.0f MB", b / 1e6)
    else -> "< 1 MB"
}

class MainVM(app: Application) : AndroidViewModel(app) {
    val projects = Repo.projects
    var openId by mutableStateOf<String?>(null)
    var showExport by mutableStateOf(false)
    var estimating by mutableStateOf(false)
    var confirm by mutableStateOf<ConfirmUi?>(null)
    var message by mutableStateOf<String?>(null)

    init { Repo.init(app) }

    fun update(p: Project) = Repo.mutate(p.id) { p }

    fun newProject(): Project {
        val now = System.currentTimeMillis()
        val p = Project(newId(), "Project ${Repo.projects.value.size + 1}", created = now, updated = now)
        Repo.add(p)
        openId = p.id
        return p
    }

    fun duplicate(p: Project) {
        val now = System.currentTimeMillis()
        Repo.add(p.copy(id = newId(), name = p.name + " 2", created = now, updated = now, outputs = emptyList()))
    }

    fun delete(id: String) {
        Repo.remove(id)
        if (openId == id) openId = null
    }

    // ---------- المصادر ----------
    fun createFromVideo(uri: Uri) {
        val p = newProject()
        addLocal(p.id, uri)
    }

    /** مشاركة من تطبيق YouTube (أو لصق نص فيه رابط/روابط) */
    fun handleShared(text: String) {
        val links = YtDl.extractLinks(text)
        if (links.isEmpty()) {
            message = tr("No YouTube link found in the shared text.", "لم يُعثر على رابط YouTube في النص المشارَك.")
            return
        }
        val p = newProject()
        addLinks(p.id, links.joinToString("\n"))
    }

    fun addLinks(id: String, text: String) {
        val links = YtDl.extractLinks(text)
        if (links.isEmpty()) {
            message = tr("No valid YouTube link found.", "لا يوجد رابط YouTube صالح.")
            return
        }
        val existing = Repo.get(id)?.sources?.map { it.uri }?.toSet() ?: emptySet()
        val fresh = links.filter { it !in existing }
        if (fresh.isEmpty()) return
        Repo.mutate(id) { p -> p.copy(sources = p.sources + fresh.map { Source(it, it.removePrefix("https://")) }) }
        val ctx = getApplication<Application>()
        for (url in fresh) {
            viewModelScope.launch {
                try {
                    val info = withContext(Dispatchers.IO) { YtDl.info(ctx, url) }
                    Repo.mutate(id) { p ->
                        val renameable = p.name.startsWith("Project ") && p.sources.size == 1
                        p.copy(
                            name = if (renameable) info.title.take(60) else p.name,
                            sources = p.sources.map { if (it.uri == url) it.copy(name = info.title, durationMs = info.durationMs, thumb = info.thumb) else it }
                        )
                    }
                } catch (e: UserError) {
                    message = e.message
                } catch (e: Throwable) {
                    message = tr("Could not read video info: ", "تعذّرت قراءة معلومات الفيديو: ") + (e.message ?: "")
                }
            }
        }
    }

    fun addLocal(id: String, uri: Uri) {
        val ctx = getApplication<Application>()
        try {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }
        viewModelScope.launch {
            val (name, dur) = withContext(Dispatchers.IO) {
                var n = "video"
                try {
                    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (i >= 0 && c.moveToFirst()) n = c.getString(i)
                    }
                } catch (_: Exception) {
                }
                var d = 0L
                val m = MediaMetadataRetriever()
                try {
                    m.setDataSource(ctx, uri)
                    d = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                } catch (_: Exception) {
                } finally {
                    m.release()
                }
                n to d
            }
            Repo.mutate(id) { p ->
                val renameable = p.name.startsWith("Project ") && p.sources.isEmpty()
                p.copy(name = if (renameable) name.substringBeforeLast('.').take(60) else p.name,
                    sources = p.sources + Source(uri.toString(), name, dur))
            }
        }
    }

    fun removeSource(id: String, idx: Int) {
        Repo.mutate(id) { p ->
            p.copy(
                sources = p.sources.filterIndexed { i, _ -> i != idx },
                clips = p.clips.map { c -> if (c.src == idx) c.copy(src = 0) else if (c.src > idx) c.copy(src = c.src - 1) else c }
            )
        }
    }

    // ---------- التصدير ----------
    private fun onCellular(ctx: Context): Boolean {
        val cm = ctx.getSystemService(ConnectivityManager::class.java) ?: return false
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
    }

    /** يتحقق من المدخلات، ويقدّر حجم تنزيل YouTube، ويطلب التأكيد قبل أي تنزيل */
    fun requestExport(p: Project) {
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            try {
                val clips = parseClips(p)
                val yt = clips.filter { p.sources[it.src].isYoutube }
                if (yt.isEmpty()) {
                    ExportEngine.enqueue(ctx, p)
                    showExport = true
                    return@launch
                }
                estimating = true
                val h = YtDl.downloadHeight(p.settings)
                val total = withContext(Dispatchers.IO) {
                    var t = 0L
                    for (c in yt) {
                        val info = YtDl.info(ctx, p.sources[c.src].uri)
                        t += YtDl.estimateBytes(info, c.startMs, c.endMs, h, p.settings.dataSaver)
                    }
                    t
                }
                estimating = false
                confirm = ConfirmUi(p, total, h, yt.size, onCellular(ctx))
            } catch (e: UserError) {
                estimating = false
                message = e.message
            } catch (e: Throwable) {
                estimating = false
                message = e.message ?: e.javaClass.simpleName
            }
        }
    }

    fun confirmExport() {
        val c = confirm ?: return
        confirm = null
        ExportEngine.enqueue(getApplication<Application>(), c.project)
        showExport = true
    }
}

class MainActivity : ComponentActivity() {
    private val vm: MainVM by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Repo.init(applicationContext)
        if (savedInstanceState == null) handleIntent(intent)
        setContent { HigTheme { App(vm) } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND && i.type?.startsWith("text/") == true) {
            val t = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
            vm.handleShared(t)
            i.action = null
        }
    }
}
