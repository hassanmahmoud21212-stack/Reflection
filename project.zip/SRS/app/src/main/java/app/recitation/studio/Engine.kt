package app.recitation.studio

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class ExportUi(
    val running: Boolean = false,
    val finished: Boolean = false,
    val current: String = "",
    val stage: String = "",
    val progress: Float = 0f,
    val queued: List<String> = emptyList(),
    val results: List<Pair<String, String>> = emptyList(),   // (اسم الملف، Uri)
    val warnings: List<String> = emptyList(),
    val errors: List<String> = emptyList()
)

/** محرك التصدير: طابور مشاريع يعمل في الخلفية داخل خدمة أمامية بإشعار تقدّم */
object ExportEngine {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    val ui = MutableStateFlow(ExportUi())
    private val pending = ArrayDeque<Project>()
    private var job: Job? = null

    fun enqueue(ctx: Context, p: Project) {
        val app = ctx.applicationContext
        Repo.init(app)
        pending.addLast(p)
        if (job?.isActive == true) {
            ui.update { it.copy(queued = pending.map { q -> q.name }) }
            return
        }
        ui.value = ExportUi(running = true, queued = pending.map { it.name }.drop(1))
        ContextCompat.startForegroundService(app, Intent(app, ExportService::class.java))
        job = scope.launch { runQueue(app) }
    }

    fun cancelAll() {
        pending.clear()
        YtDl.cancel("srs")
        job?.cancel()
    }

    fun clearDone() {
        if (!ui.value.running) ui.value = ExportUi()
    }

    private suspend fun runQueue(app: Context) {
        try {
            while (pending.isNotEmpty()) {
                val p = pending.removeFirst()
                ui.update { it.copy(running = true, current = p.name, stage = "", progress = 0f, queued = pending.map { q -> q.name }) }
                try {
                    runProject(app, p)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: UserError) {
                    addError("${p.name}: ${e.message}")
                } catch (e: Throwable) {
                    addError("${p.name}: " + tr("Export failed: ", "فشل التصدير: ") + (e.message ?: e.javaClass.simpleName))
                }
            }
        } finally {
            pending.clear()
            ui.update { it.copy(running = false, finished = true, current = "", queued = emptyList()) }
        }
    }

    private fun addError(m: String) = ui.update { it.copy(errors = it.errors + m) }
    private fun warn(m: String) = ui.update { it.copy(warnings = it.warnings + m) }
    private fun stage(m: String) = ui.update { it.copy(stage = m) }
    private fun prog(v: Float) = ui.update { it.copy(progress = v.coerceIn(0f, 1f)) }

    private suspend fun runProject(ctx: Context, p: Project) {
        val clips = parseClips(p)
        val s = p.settings
        val safe = p.name.replace(Regex("""[\\/:*?"<>|]"""), "_").trim().ifEmpty { "Project" }
        val tag = when (s.orientation) { 0 -> "portrait"; 1 -> "landscape"; else -> "original" }
        val doTrack = s.orientation != 2 && s.framing == 0
        val trW = if (doTrack) 0.2f else 0f
        val maxH = YtDl.downloadHeight(s)
        val outUris = mutableListOf<String>()

        for ((k, c) in clips.withIndex()) {
            val sr = p.sources[c.src]
            val yt = sr.isYoutube
            val dlW = if (yt) 0.3f else 0f
            val enW = 1f - dlW - trW
            val base = k.toFloat() / clips.size
            val span = 1f / clips.size
            val n = k + 1
            val of = "$n/${clips.size}"
            var src: Uri = if (yt) Uri.EMPTY else Uri.parse(sr.uri)
            var cs = c.startMs
            var ce = c.endMs
            var tmp: File? = null
            try {
                if (yt) {
                    stage(tr("Clip $of: downloading only this part…", "المقطع $of: تنزيل هذا الجزء فقط…"))
                    val dl = withContext(Dispatchers.IO) {
                        YtDl.downloadSection(ctx, sr.uri, c.startMs, c.endMs, maxH, s.dataSaver, File(ctx.cacheDir, "yt"), "p${p.id.take(6)}_c$n", "srs") { f ->
                            prog(base + span * dlW * f)
                        }
                    }
                    tmp = dl.file
                    src = Uri.fromFile(dl.file)
                    val real = withContext(Dispatchers.IO) { Tracker.durationMs(ctx, src) }
                    if (real <= 0) throw UserError(tr("The downloaded part is unreadable.", "الجزء المنزَّل غير قابل للقراءة."))
                    cs = 0
                    ce = minOf(c.endMs - c.startMs, real)
                    if (!dl.exact)
                        warn(tr("Clip $of: exact-cut mode was unavailable; the start may be off by a few seconds.", "المقطع $of: وضع القص الدقيق غير متاح؛ قد تختلف البداية بضع ثوانٍ."))
                }
                var track: TrackResult? = null
                if (doTrack) {
                    stage(tr("Clip $of: tracking face…", "المقطع $of: تتبع الوجه…"))
                    track = withContext(Dispatchers.Default) {
                        Tracker.analyze(ctx, src, cs, ce, s.subject) { f -> prog(base + span * (dlW + trW * f)) }
                    }
                    val cov = track.detected * 100 / track.samples.coerceAtLeast(1)
                    if (track.detected == 0)
                        warn(tr("Clip $of: no face found — centered crop used.", "المقطع $of: لم يُعثر على وجه — استُخدم قص من المنتصف."))
                    else if (cov < 50)
                        warn(tr("Clip $of: face found in only $cov% of samples — check the result.", "المقطع $of: الوجه ظهر في $cov% فقط من العيّنات — راجع النتيجة."))
                }
                stage(tr("Clip $of: encoding…", "المقطع $of: ترميز…"))
                val out = Exporter.export(ctx, src, s, cs, ce, track) { f -> prog(base + span * (dlW + trW + enW * f)) }
                if (out.plan.upscaled)
                    warn(tr("Clip $of: output is larger than the source detail (upscaled).", "المقطع $of: الدقة المختارة أكبر من تفاصيل المصدر (تكبير)."))
                val name = "${safe}_clip${n}_$tag.mp4"
                val u = withContext(Dispatchers.IO) { Exporter.publish(ctx, out.file, name, safe) }
                outUris += u.toString()
                ui.update { it.copy(results = it.results + (name to u.toString())) }
                prog(base + span)
            } finally {
                tmp?.delete()
            }
        }
        Repo.mutate(p.id) { it.copy(outputs = it.outputs + outUris) }
    }
}

class ExportService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var watcher: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) ExportEngine.cancelAll()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, tr("Export", "التصدير"), NotificationManager.IMPORTANCE_LOW))
        startForeground(NOTIF_ID, build(tr("Preparing…", "جارٍ التجهيز…"), 0, tr("Exporting", "جارٍ التصدير")),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        if (watcher == null) {
            watcher = scope.launch {
                var last = -1
                ExportEngine.ui.collect { u ->
                    if (u.running) {
                        val pct = (u.progress * 100).toInt()
                        val key = pct * 1000 + u.stage.hashCode() % 1000
                        if (key != last) {
                            last = key
                            val q = if (u.queued.isNotEmpty()) "  ·  +${u.queued.size}" else ""
                            nm.notify(NOTIF_ID, build(u.stage + q, pct, tr("Exporting", "جارٍ التصدير") + " · " + u.current))
                        }
                    } else {
                        val n = u.results.size
                        if (n > 0 || u.errors.isNotEmpty()) {
                            val text = if (u.errors.isEmpty()) tr("$n file(s) saved to Movies.", "حُفظ $n ملف في Movies.")
                            else u.errors.first().take(120)
                            nm.notify(NOTIF_ID + 1, NotificationCompat.Builder(this@ExportService, CH)
                                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                                .setContentTitle(tr("Export finished", "انتهى التصدير"))
                                .setContentText(text).setAutoCancel(true).setContentIntent(openApp()).build())
                        }
                        stopForeground(STOP_FOREGROUND_REMOVE)
                        stopSelf()
                    }
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun openApp(): PendingIntent = PendingIntent.getActivity(
        this, 0,
        Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE
    )

    private fun build(text: String, pct: Int, title: String): Notification {
        val cancel = PendingIntent.getService(
            this, 1, Intent(this, ExportService::class.java).setAction(ACTION_CANCEL), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title).setContentText(text)
            .setOnlyAlertOnce(true).setOngoing(true)
            .setProgress(100, pct, false)
            .setContentIntent(openApp())
            .addAction(0, tr("Cancel", "إلغاء"), cancel)
            .build()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val CH = "export"
        const val NOTIF_ID = 41
        const val ACTION_CANCEL = "app.recitation.studio.CANCEL"
    }
}
